/* ================================================================
   DAA LAB EXAM — ALL ALGORITHMS IN ONE FILE
   All 20 codes are independent — copy whichever you need.
   Verified compiling & running on g++ 13.3 (May 2026)
   ================================================================ */


/* ==================== 01_MergeSort ==================== */

#include <iostream>
using namespace std;

// Merge two sorted halves: arr[l..m] and arr[m+1..r]
void merge(int arr[], int l, int m, int r) {
    int n1 = m - l + 1;
    int n2 = r - m;
    int L[n1], R[n2];

    for (int i = 0; i < n1; i++) L[i] = arr[l + i];
    for (int j = 0; j < n2; j++) R[j] = arr[m + 1 + j];

    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) arr[k++] = L[i++];
        else              arr[k++] = R[j++];
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
}

void mergeSort(int arr[], int l, int r) {
    if (l < r) {
        int m = l + (r - l) / 2;   // avoids integer overflow
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}

int main() {
    int arr[] = {12, 11, 13, 5, 6, 7};
    int n = sizeof(arr) / sizeof(arr[0]);
    mergeSort(arr, 0, n - 1);
    cout << "Sorted array: ";
    for (int i = 0; i < n; i++) cout << arr[i] << " ";
    return 0;
}


/* ==================== 02_QuickSort ==================== */

#include <iostream>
using namespace std;

int partition(int arr[], int low, int high) {
    int pivot = arr[high];          // choosing last element as pivot
    int i = low - 1;                // boundary of "smaller-than-pivot" region
    for (int j = low; j < high; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;
}

void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

int main() {
    int arr[] = {10, 7, 8, 9, 1, 5};
    int n = sizeof(arr)/sizeof(arr[0]);
    quickSort(arr, 0, n - 1);
    cout << "Sorted: ";
    for (int i = 0; i < n; i++) cout << arr[i] << " ";
    return 0;
}


/* ==================== 03_QuickSort_MedianOfMedians ==================== */

#include <iostream>
#include <algorithm>
#include <vector>
#include <climits>
using namespace std;

// Insertion sort for groups of 5
int findMedian(vector<int>& arr, int l, int n) {
    sort(arr.begin() + l, arr.begin() + l + n);
    return arr[l + n / 2];
}

// Returns the k-th smallest using median-of-medians pivot
int kthSmallest(vector<int>& arr, int l, int r, int k);

int partitionAround(vector<int>& arr, int l, int r, int x) {
    int i;
    for (i = l; i < r; i++) if (arr[i] == x) break;
    swap(arr[i], arr[r]);
    i = l;
    for (int j = l; j < r; j++) {
        if (arr[j] <= x) {
            swap(arr[i], arr[j]);
            i++;
        }
    }
    swap(arr[i], arr[r]);
    return i;
}

int kthSmallest(vector<int>& arr, int l, int r, int k) {
    if (k > 0 && k <= r - l + 1) {
        int n = r - l + 1;
        int i;
        vector<int> medians((n + 4) / 5);
        for (i = 0; i < n / 5; i++)
            medians[i] = findMedian(arr, l + i * 5, 5);
        if (i * 5 < n) {
            medians[i] = findMedian(arr, l + i * 5, n % 5);
            i++;
        }
        int medOfMed = (i == 1) ? medians[i - 1]
                                : kthSmallest(medians, 0, i - 1, i / 2);
        int pos = partitionAround(arr, l, r, medOfMed);
        if (pos - l == k - 1) return arr[pos];
        if (pos - l > k - 1)  return kthSmallest(arr, l, pos - 1, k);
        return kthSmallest(arr, pos + 1, r, k - pos + l - 1);
    }
    return INT_MAX;
}

void quickSortMoM(vector<int>& arr, int l, int r) {
    if (l < r) {
        int n = r - l + 1;
        int median = kthSmallest(arr, l, r, n / 2 + 1);
        int pi = partitionAround(arr, l, r, median);
        quickSortMoM(arr, l, pi - 1);
        quickSortMoM(arr, pi + 1, r);
    }
}

int main() {
    vector<int> arr = {12, 3, 5, 7, 4, 19, 26};
    quickSortMoM(arr, 0, arr.size() - 1);
    cout << "Sorted: ";
    for (int x : arr) cout << x << " ";
    return 0;
}


/* ==================== 04_Karatsuba ==================== */

#include <iostream>
#include <string>
#include <cmath>
using namespace std;

long long karatsuba(long long x, long long y) {
    // Base case: small numbers — multiply directly
    if (x < 10 || y < 10) return x * y;

    // Calculate the number of digits
    int n = max(to_string(x).length(), to_string(y).length());
    int half = n / 2;
    long long power = (long long)pow(10, half);

    long long a = x / power;
    long long b = x % power;
    long long c = y / power;
    long long d = y % power;

    long long ac = karatsuba(a, c);
    long long bd = karatsuba(b, d);
    long long ad_plus_bc = karatsuba(a + b, c + d) - ac - bd;

    return ac * (long long)pow(10, 2 * half)
         + ad_plus_bc * power
         + bd;
}

int main() {
    long long x = 1234, y = 5678;
    cout << x << " * " << y << " = " << karatsuba(x, y) << endl;
    // Expected: 7006652
    return 0;
}


/* ==================== 05_Strassen ==================== */

#include <iostream>
#include <vector>
using namespace std;

typedef vector<vector<int>> Matrix;

Matrix add(Matrix A, Matrix B) {
    int n = A.size();
    Matrix C(n, vector<int>(n));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            C[i][j] = A[i][j] + B[i][j];
    return C;
}

Matrix sub(Matrix A, Matrix B) {
    int n = A.size();
    Matrix C(n, vector<int>(n));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            C[i][j] = A[i][j] - B[i][j];
    return C;
}

Matrix strassen(Matrix A, Matrix B) {
    int n = A.size();
    Matrix C(n, vector<int>(n));

    // Base case
    if (n == 1) { C[0][0] = A[0][0] * B[0][0]; return C; }

    int k = n / 2;
    Matrix A11(k, vector<int>(k)), A12(k, vector<int>(k)),
           A21(k, vector<int>(k)), A22(k, vector<int>(k));
    Matrix B11(k, vector<int>(k)), B12(k, vector<int>(k)),
           B21(k, vector<int>(k)), B22(k, vector<int>(k));

    // Divide matrices into 4 quadrants
    for (int i = 0; i < k; i++) {
        for (int j = 0; j < k; j++) {
            A11[i][j] = A[i][j];
            A12[i][j] = A[i][j + k];
            A21[i][j] = A[i + k][j];
            A22[i][j] = A[i + k][j + k];
            B11[i][j] = B[i][j];
            B12[i][j] = B[i][j + k];
            B21[i][j] = B[i + k][j];
            B22[i][j] = B[i + k][j + k];
        }
    }

    // 7 Strassen products
    Matrix M1 = strassen(add(A11, A22), add(B11, B22));
    Matrix M2 = strassen(add(A21, A22), B11);
    Matrix M3 = strassen(A11, sub(B12, B22));
    Matrix M4 = strassen(A22, sub(B21, B11));
    Matrix M5 = strassen(add(A11, A12), B22);
    Matrix M6 = strassen(sub(A21, A11), add(B11, B12));
    Matrix M7 = strassen(sub(A12, A22), add(B21, B22));

    // Combine into result quadrants
    Matrix C11 = add(sub(add(M1, M4), M5), M7);
    Matrix C12 = add(M3, M5);
    Matrix C21 = add(M2, M4);
    Matrix C22 = add(sub(add(M1, M3), M2), M6);

    for (int i = 0; i < k; i++) {
        for (int j = 0; j < k; j++) {
            C[i][j]         = C11[i][j];
            C[i][j + k]     = C12[i][j];
            C[i + k][j]     = C21[i][j];
            C[i + k][j + k] = C22[i][j];
        }
    }
    return C;
}

int main() {
    Matrix A = {{1, 2}, {3, 4}};
    Matrix B = {{5, 6}, {7, 8}};
    Matrix C = strassen(A, B);
    cout << "Result:\n";
    for (auto& row : C) {
        for (int x : row) cout << x << " ";
        cout << "\n";
    }
    // Expected: 19 22 / 43 50
    return 0;
}


/* ==================== 06_FractionalKnapsack ==================== */

#include <iostream>
#include <algorithm>
using namespace std;

struct Item {
    int value, weight;
};

bool cmp(Item a, Item b) {
    double r1 = (double)a.value / a.weight;
    double r2 = (double)b.value / b.weight;
    return r1 > r2;   // higher ratio first
}

double fractionalKnapsack(int W, Item arr[], int n) {
    sort(arr, arr + n, cmp);
    double totalValue = 0.0;
    for (int i = 0; i < n; i++) {
        if (arr[i].weight <= W) {
            W -= arr[i].weight;
            totalValue += arr[i].value;
        } else {
            // Take fractional part
            totalValue += arr[i].value * ((double)W / arr[i].weight);
            break;
        }
    }
    return totalValue;
}

int main() {
    Item arr[] = {{60, 10}, {100, 20}, {120, 30}};
    int W = 50;
    int n = sizeof(arr) / sizeof(arr[0]);
    cout << "Maximum value = " << fractionalKnapsack(W, arr, n);
    // Expected: 240
    return 0;
}


/* ==================== 07_JobSequencing ==================== */

#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;

struct Job {
    char id;
    int deadline;
    int profit;
};

bool cmp(Job a, Job b) { return a.profit > b.profit; }

void jobSequencing(Job arr[], int n) {
    sort(arr, arr + n, cmp);

    int maxDeadline = 0;
    for (int i = 0; i < n; i++)
        maxDeadline = max(maxDeadline, arr[i].deadline);

    char slot[maxDeadline + 1];
    memset(slot, '-', sizeof(slot));

    int totalProfit = 0;
    int jobsDone = 0;

    for (int i = 0; i < n; i++) {
        // Find a free slot before deadline (latest possible)
        for (int j = min(maxDeadline, arr[i].deadline); j > 0; j--) {
            if (slot[j] == '-') {
                slot[j] = arr[i].id;
                totalProfit += arr[i].profit;
                jobsDone++;
                break;
            }
        }
    }

    cout << "Scheduled jobs: ";
    for (int i = 1; i <= maxDeadline; i++)
        if (slot[i] != '-') cout << slot[i] << " ";
    cout << "\nTotal profit: " << totalProfit;
    cout << "\nJobs done: " << jobsDone << endl;
}

int main() {
    Job arr[] = {{'a', 2, 100}, {'b', 1, 19}, {'c', 2, 27},
                 {'d', 1, 25}, {'e', 3, 15}};
    int n = sizeof(arr) / sizeof(arr[0]);
    jobSequencing(arr, n);
    return 0;
}


/* ==================== 08_Huffman ==================== */

#include <iostream>
#include <queue>
#include <unordered_map>
using namespace std;

struct Node {
    char ch;
    int freq;
    Node *left, *right;
    Node(char c, int f) : ch(c), freq(f), left(nullptr), right(nullptr) {}
};

struct Compare {
    bool operator()(Node* a, Node* b) { return a->freq > b->freq; }
};

void generateCodes(Node* root, string code,
                   unordered_map<char, string>& huffCode) {
    if (!root) return;
    if (!root->left && !root->right) {
        huffCode[root->ch] = code;
        return;
    }
    generateCodes(root->left,  code + "0", huffCode);
    generateCodes(root->right, code + "1", huffCode);
}

void huffmanCoding(string text) {
    unordered_map<char, int> freq;
    for (char c : text) freq[c]++;

    priority_queue<Node*, vector<Node*>, Compare> pq;
    for (auto& p : freq) pq.push(new Node(p.first, p.second));

    while (pq.size() > 1) {
        Node* left  = pq.top(); pq.pop();
        Node* right = pq.top(); pq.pop();
        Node* merged = new Node('$', left->freq + right->freq);
        merged->left  = left;
        merged->right = right;
        pq.push(merged);
    }

    Node* root = pq.top();
    unordered_map<char, string> huffCode;
    generateCodes(root, "", huffCode);

    cout << "Character codes:\n";
    for (auto& p : huffCode) cout << p.first << " : " << p.second << "\n";

    cout << "\nEncoded string: ";
    for (char c : text) cout << huffCode[c];
    cout << endl;
}

int main() {
    string text = "huffman";
    huffmanCoding(text);
    return 0;
}


/* ==================== 09_CoinChange_Greedy ==================== */

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

void coinChangeGreedy(vector<int> coins, int amount) {
    sort(coins.begin(), coins.end(), greater<int>());
    vector<int> used;
    for (int c : coins) {
        while (amount >= c) {
            amount -= c;
            used.push_back(c);
        }
    }
    if (amount != 0) {
        cout << "Greedy failed — exact change not possible (or system non-canonical).\n";
        return;
    }
    cout << "Coins used (" << used.size() << "): ";
    for (int x : used) cout << x << " ";
    cout << endl;
}

int main() {
    vector<int> coins = {1, 2, 5, 10, 20, 50, 100, 500, 2000};   // Indian Rupee
    coinChangeGreedy(coins, 93);
    // Expected: 50 20 20 2 1 (5 coins)
    return 0;
}


/* ==================== 10_CoinChange_DP ==================== */

#include <iostream>
#include <vector>
#include <climits>
using namespace std;

int coinChangeDP(vector<int>& coins, int amount) {
    // dp[i] = min coins to make amount i
    vector<int> dp(amount + 1, INT_MAX);
    dp[0] = 0;

    for (int i = 1; i <= amount; i++) {
        for (int c : coins) {
            if (c <= i && dp[i - c] != INT_MAX) {
                dp[i] = min(dp[i], dp[i - c] + 1);
            }
        }
    }
    return (dp[amount] == INT_MAX) ? -1 : dp[amount];
}

int main() {
    vector<int> coins = {1, 3, 4};
    int amount = 6;
    int result = coinChangeDP(coins, amount);
    cout << "Min coins for " << amount << ": " << result << endl;
    // Expected: 2  (3 + 3)
    return 0;
}


/* ==================== 11_Knapsack01_DP ==================== */

#include <iostream>
#include <vector>
using namespace std;

int knapsackDP(int W, vector<int>& wt, vector<int>& val, int n) {
    vector<vector<int>> dp(n + 1, vector<int>(W + 1, 0));

    for (int i = 1; i <= n; i++) {
        for (int w = 0; w <= W; w++) {
            if (wt[i - 1] <= w) {
                dp[i][w] = max(dp[i - 1][w],
                               dp[i - 1][w - wt[i - 1]] + val[i - 1]);
            } else {
                dp[i][w] = dp[i - 1][w];
            }
        }
    }

    // Trace back to find which items were chosen
    cout << "Items selected: ";
    int w = W;
    for (int i = n; i > 0; i--) {
        if (dp[i][w] != dp[i - 1][w]) {
            cout << "item" << i << " ";
            w -= wt[i - 1];
        }
    }
    cout << endl;

    return dp[n][W];
}

int main() {
    vector<int> val = {60, 100, 120};
    vector<int> wt  = {10, 20, 30};
    int W = 50;
    int n = val.size();
    cout << "Max value: " << knapsackDP(W, wt, val, n) << endl;
    // Expected: 220 (items 2 and 3)
    return 0;
}


/* ==================== 12_Knapsack01_BranchBound ==================== */

#include <iostream>
#include <queue>
#include <algorithm>
using namespace std;

struct Item {
    float value, weight;
};

struct Node {
    int level;        // level in decision tree (item index)
    float profit;     // accumulated profit
    float weight;     // accumulated weight
    float bound;      // upper bound on best profit from this node
};

bool cmp(Item a, Item b) {
    return (a.value / a.weight) > (b.value / b.weight);
}

// Bound = current profit + fractional fill of remaining items
float bound(Node u, int n, int W, Item arr[]) {
    if (u.weight >= W) return 0;
    float profit_bound = u.profit;
    int j = u.level + 1;
    float totweight = u.weight;
    while (j < n && totweight + arr[j].weight <= W) {
        totweight   += arr[j].weight;
        profit_bound += arr[j].value;
        j++;
    }
    if (j < n)
        profit_bound += (W - totweight) * arr[j].value / arr[j].weight;
    return profit_bound;
}

struct Compare {
    bool operator()(Node a, Node b) { return a.bound < b.bound; }
};

float knapsackBB(int W, Item arr[], int n) {
    sort(arr, arr + n, cmp);

    priority_queue<Node, vector<Node>, Compare> pq;
    Node u, v;
    u.level = -1; u.profit = 0; u.weight = 0;
    u.bound = bound(u, n, W, arr);
    pq.push(u);

    float maxProfit = 0;
    while (!pq.empty()) {
        u = pq.top(); pq.pop();
        if (u.bound <= maxProfit) continue;   // prune!
        if (u.level == n - 1) continue;

        // Branch 1: include next item
        v.level  = u.level + 1;
        v.weight = u.weight + arr[v.level].weight;
        v.profit = u.profit + arr[v.level].value;
        if (v.weight <= W && v.profit > maxProfit) maxProfit = v.profit;
        v.bound = bound(v, n, W, arr);
        if (v.bound > maxProfit) pq.push(v);

        // Branch 2: exclude next item
        v.weight = u.weight;
        v.profit = u.profit;
        v.bound  = bound(v, n, W, arr);
        if (v.bound > maxProfit) pq.push(v);
    }
    return maxProfit;
}

int main() {
    Item arr[] = {{40, 2}, {30, 5}, {50, 10}, {10, 5}};
    int W = 16;
    int n = sizeof(arr) / sizeof(arr[0]);
    cout << "Maximum profit = " << knapsackBB(W, arr, n) << endl;
    return 0;
}


/* ==================== 13_SumOfSubsets_BranchBound ==================== */

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void sumOfSubsets(vector<int>& nums, int idx, int currSum, int target,
                  int remainingSum, vector<int>& subset) {
    // Found a valid subset
    if (currSum == target) {
        cout << "{ ";
        for (int x : subset) cout << x << " ";
        cout << "}\n";
        return;
    }

    // Pruning conditions
    if (idx >= nums.size()) return;
    if (currSum + remainingSum < target) return;     // can't reach target
    if (currSum + nums[idx] > target) return;        // overshoot if included

    // Include nums[idx]
    subset.push_back(nums[idx]);
    sumOfSubsets(nums, idx + 1, currSum + nums[idx], target,
                 remainingSum - nums[idx], subset);
    subset.pop_back();

    // Exclude nums[idx]
    sumOfSubsets(nums, idx + 1, currSum, target,
                 remainingSum - nums[idx], subset);
}

int main() {
    vector<int> nums = {5, 10, 12, 13, 15, 18};
    int target = 30;

    sort(nums.begin(), nums.end());   // sorting improves pruning
    int totalSum = 0;
    for (int x : nums) totalSum += x;

    vector<int> subset;
    cout << "Subsets summing to " << target << ":\n";
    sumOfSubsets(nums, 0, 0, target, totalSum, subset);
    return 0;
}


/* ==================== 14_GraphColoring ==================== */

#include <iostream>
#include <vector>
using namespace std;

bool isSafe(int v, vector<vector<int>>& graph, vector<int>& color,
            int c, int V) {
    for (int i = 0; i < V; i++)
        if (graph[v][i] && color[i] == c) return false;
    return true;
}

bool graphColoringUtil(vector<vector<int>>& graph, int m, vector<int>& color,
                       int v, int V) {
    if (v == V) return true;     // all vertices colored

    for (int c = 1; c <= m; c++) {
        if (isSafe(v, graph, color, c, V)) {
            color[v] = c;
            if (graphColoringUtil(graph, m, color, v + 1, V)) return true;
            color[v] = 0;        // backtrack
        }
    }
    return false;
}

bool graphColoring(vector<vector<int>>& graph, int m, int V) {
    vector<int> color(V, 0);
    if (!graphColoringUtil(graph, m, color, 0, V)) {
        cout << "Solution does not exist with " << m << " colors.\n";
        return false;
    }
    cout << "Coloring assignment:\n";
    for (int i = 0; i < V; i++)
        cout << "Vertex " << i << " -> Color " << color[i] << "\n";
    return true;
}

int main() {
    // Graph: 4 vertices, square shape
    int V = 4;
    vector<vector<int>> graph = {{0, 1, 1, 1},
                                 {1, 0, 1, 0},
                                 {1, 1, 0, 1},
                                 {1, 0, 1, 0}};
    int m = 3;
    graphColoring(graph, m, V);
    return 0;
}


/* ==================== 15_NQueens ==================== */

#include <iostream>
#include <vector>
using namespace std;

bool isSafe(vector<vector<int>>& board, int row, int col, int N) {
    // Check left columns in this row
    for (int i = 0; i < col; i++)
        if (board[row][i]) return false;

    // Upper-left diagonal
    for (int i = row, j = col; i >= 0 && j >= 0; i--, j--)
        if (board[i][j]) return false;

    // Lower-left diagonal
    for (int i = row, j = col; j >= 0 && i < N; i++, j--)
        if (board[i][j]) return false;

    return true;
}

bool solveNQueens(vector<vector<int>>& board, int col, int N) {
    if (col >= N) return true;     // all queens placed

    for (int i = 0; i < N; i++) {
        if (isSafe(board, i, col, N)) {
            board[i][col] = 1;
            if (solveNQueens(board, col + 1, N)) return true;
            board[i][col] = 0;     // backtrack
        }
    }
    return false;
}

int main() {
    int N = 4;
    vector<vector<int>> board(N, vector<int>(N, 0));

    if (!solveNQueens(board, 0, N)) {
        cout << "No solution exists.\n";
        return 0;
    }

    cout << "Board:\n";
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++)
            cout << (board[i][j] ? "Q " : ". ");
        cout << "\n";
    }
    return 0;
}


/* ==================== 16_NaiveStringMatch ==================== */

#include <iostream>
#include <string>
using namespace std;

void naiveSearch(string text, string pattern) {
    int n = text.length();
    int m = pattern.length();

    for (int i = 0; i <= n - m; i++) {
        int j = 0;
        while (j < m && text[i + j] == pattern[j]) j++;
        if (j == m) cout << "Pattern found at index " << i << endl;
    }
}

int main() {
    string text    = "AABAACAADAABAABA";
    string pattern = "AABA";
    naiveSearch(text, pattern);
    // Expected: 0, 9, 12
    return 0;
}


/* ==================== 17_KMP ==================== */

#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Compute LPS (Longest Proper Prefix that's also a Suffix) array
void computeLPS(string& pattern, vector<int>& lps) {
    int m = pattern.length();
    int len = 0;
    lps[0] = 0;
    int i = 1;
    while (i < m) {
        if (pattern[i] == pattern[len]) {
            len++;
            lps[i++] = len;
        } else {
            if (len != 0) len = lps[len - 1];
            else          lps[i++] = 0;
        }
    }
}

void KMPSearch(string text, string pattern) {
    int n = text.length();
    int m = pattern.length();
    vector<int> lps(m);
    computeLPS(pattern, lps);

    int i = 0, j = 0;
    while (i < n) {
        if (pattern[j] == text[i]) { i++; j++; }
        if (j == m) {
            cout << "Pattern found at index " << i - j << endl;
            j = lps[j - 1];
        } else if (i < n && pattern[j] != text[i]) {
            if (j != 0) j = lps[j - 1];
            else        i++;
        }
    }
}

int main() {
    string text    = "ABABDABACDABABCABAB";
    string pattern = "ABABCABAB";
    KMPSearch(text, pattern);
    // Expected: 10
    return 0;
}


/* ==================== 18_RabinKarp ==================== */

#include <iostream>
#include <string>
using namespace std;

#define d 256          // alphabet size
#define q 101          // a prime number

void rabinKarp(string text, string pattern) {
    int n = text.length();
    int m = pattern.length();
    int h = 1;
    int p_hash = 0;    // pattern hash
    int t_hash = 0;    // text window hash

    // h = d^(m-1) % q
    for (int i = 0; i < m - 1; i++) h = (h * d) % q;

    // Initial hashes for pattern and first window
    for (int i = 0; i < m; i++) {
        p_hash = (d * p_hash + pattern[i]) % q;
        t_hash = (d * t_hash + text[i])    % q;
    }

    for (int i = 0; i <= n - m; i++) {
        if (p_hash == t_hash) {
            // Verify character by character (handle hash collisions)
            int j = 0;
            while (j < m && text[i + j] == pattern[j]) j++;
            if (j == m) cout << "Pattern found at index " << i << endl;
        }
        // Rolling hash: remove leading char, add trailing
        if (i < n - m) {
            t_hash = (d * (t_hash - text[i] * h) + text[i + m]) % q;
            if (t_hash < 0) t_hash += q;
        }
    }
}

int main() {
    string text    = "GEEKS FOR GEEKS";
    string pattern = "GEEK";
    rabinKarp(text, pattern);
    // Expected: 0, 10
    return 0;
}


/* ==================== 19_BoyerMoore ==================== */

#include <iostream>
#include <string>
#include <cstring>
using namespace std;

#define NO_OF_CHARS 256

void badCharHeuristic(string str, int size, int badchar[NO_OF_CHARS]) {
    for (int i = 0; i < NO_OF_CHARS; i++) badchar[i] = -1;
    for (int i = 0; i < size; i++) badchar[(int)str[i]] = i;
}

void boyerMoore(string text, string pattern) {
    int n = text.length();
    int m = pattern.length();
    int badchar[NO_OF_CHARS];
    badCharHeuristic(pattern, m, badchar);

    int s = 0;     // shift of the pattern w.r.t. text
    while (s <= n - m) {
        int j = m - 1;
        // Match from right to left
        while (j >= 0 && pattern[j] == text[s + j]) j--;

        if (j < 0) {
            cout << "Pattern found at index " << s << endl;
            s += (s + m < n) ? m - badchar[text[s + m]] : 1;
        } else {
            s += max(1, j - badchar[text[s + j]]);
        }
    }
}

int main() {
    string text    = "ABAAABCD";
    string pattern = "ABC";
    boyerMoore(text, pattern);
    // Expected: 4
    return 0;
}


/* ==================== 20_RandomizedQuickSort ==================== */

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;
}

int randomPartition(int arr[], int low, int high) {
    int n = high - low + 1;
    int random = low + rand() % n;
    swap(arr[random], arr[high]);     // move random pivot to the end
    return partition(arr, low, high);
}

void randomizedQuickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = randomPartition(arr, low, high);
        randomizedQuickSort(arr, low, pi - 1);
        randomizedQuickSort(arr, pi + 1, high);
    }
}

int main() {
    srand(time(0));
    int arr[] = {10, 7, 8, 9, 1, 5};
    int n = sizeof(arr) / sizeof(arr[0]);
    randomizedQuickSort(arr, 0, n - 1);
    cout << "Sorted: ";
    for (int i = 0; i < n; i++) cout << arr[i] << " ";
    return 0;
}

