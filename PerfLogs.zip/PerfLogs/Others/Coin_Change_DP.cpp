#include <iostream>
#include <chrono>
using namespace std;
using namespace std::chrono;

int main()
{
    int n, V;

    cout << "Enter number of coins: ";
    cin >> n;

    int coin[50];
    cout << "Enter coin values: ";
    for (int i = 0; i < n; i++)
        cin >> coin[i];

    cout << "Enter amount: ";
    cin >> V;

    int originalV = V;

    auto g_start = high_resolution_clock::now();

    /* -------- GREEDY METHOD -------- */

    // Sort coins in descending order (Bubble Sort)
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (coin[j] < coin[j + 1])
            {
                int temp = coin[j];
                coin[j] = coin[j + 1];
                coin[j + 1] = temp;
            }
        }
    }

    int greedyCount = 0;
    int greedyV = V;

    for (int i = 0; i < n; i++)
    {
        while (greedyV >= coin[i])
        {
            greedyV -= coin[i];
            greedyCount++;
        }
    }

    auto g_end = high_resolution_clock::now();
    auto greedy_time = duration_cast<nanoseconds>(g_end - g_start);

    cout << "\n--- Greedy Method ---\n";
    if (greedyV == 0)
        cout << "Coins required (Greedy): " << greedyCount << endl;
    else
        cout << "Amount cannot be formed using Greedy\n";

    cout << "Greedy Execution Time: " << greedy_time.count() << " nanoseconds\n";

    /* -------- DYNAMIC PROGRAMMING METHOD -------- */

    int dp[100000];

    auto d_start = high_resolution_clock::now();

    dp[0] = 0;
    for (int i = 1; i <= originalV; i++)
        dp[i] = 1000000;

    for (int i = 1; i <= originalV; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (coin[j] <= i)
            {
                int val = dp[i - coin[j]] + 1;
                if (val < dp[i])
                    dp[i] = val;
            }
        }
    }

    auto d_end = high_resolution_clock::now();
    auto dp_time = duration_cast<nanoseconds>(d_end - d_start);

    cout << "\n--- Dynamic Programming Method ---\n";
    if (dp[originalV] == 1000000)
        cout << "Amount cannot be formed using DP\n";
    else
        cout << "Minimum coins required (DP): " << dp[originalV] << endl;

    cout << "DP Execution Time: " << dp_time.count() << " nanoseconds\n";

    return 0;
}