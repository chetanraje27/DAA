// Practical :- Boyer Moore Pattern Matching Algorithm
// Name :- Jagdish Babalsure
// PRN  :- 202301040166

#include <iostream>
#include <chrono>

using namespace std;
using namespace chrono;

// Function to calculate string length
int stringLength(char str[])
{
    int len = 0;

    while (str[len] != '\0')
    {
        len++;
    }

    return len;
}

// Function to build Bad Character Table
void badCharTable(char pattern[], int size, int badChar[])
{
    // Initialize all occurrences as -1
    for (int i = 0; i < 256; i++)
    {
        badChar[i] = -1;
    }

    // Fill actual positions
    for (int i = 0; i < size; i++)
    {
        badChar[(int)pattern[i]] = i;
    }
}

// Boyer Moore Search Function
void boyerMooreSearch(char text[], char pattern[])
{
    int m = stringLength(pattern);
    int n = stringLength(text);

    int badChar[256];

    badCharTable(pattern, m, badChar);

    int shift = 0;
    int found = 0;

    while (shift <= (n - m))
    {
        int j = m - 1;

        // Compare from right to left
        while (j >= 0 && pattern[j] == text[shift + j])
        {
            j--;
        }

        // Pattern found
        if (j < 0)
        {
            cout << "Pattern found at index: " << shift << endl;
            found = 1;

            if (shift + m < n)
            {
                shift += m - badChar[(int)text[shift + m]];
            }
            else
            {
                shift += 1;
            }
        }
        else
        {
            int badIndex = badChar[(int)text[shift + j]];

            if ((j - badIndex) > 1)
            {
                shift += j - badIndex;
            }
            else
            {
                shift += 1;
            }
        }
    }

    if (!found)
    {
        cout << "Pattern not found in the text." << endl;
    }
}

int main()
{
    char text[1000];
    char pattern[100];

    cout << "Enter the main text: ";
    cin.getline(text, 1000);

    cout << "Enter the pattern to search: ";
    cin.getline(pattern, 100);

    auto startTime = steady_clock::now();

    boyerMooreSearch(text, pattern);

    auto endTime = steady_clock::now();

    auto timeTaken = duration_cast<nanoseconds>(endTime - startTime);

    cout << "Execution Time: " << timeTaken.count() << " nanoseconds" << endl;

    return 0;
}