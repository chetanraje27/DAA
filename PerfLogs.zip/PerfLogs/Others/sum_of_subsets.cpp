#include <iostream>
#include <chrono>
using namespace std::chrono;
using namespace std;

int w[50];
int x[50];
int n, target;

void print()
{
    cout << "Subset: ";
    for (int i = 0; i < n; i++)
    {
        if (x[i] == 1)
            cout << w[i] << " ";
    }
    cout << endl;
}

void sum_of_subsets(int k, int curr_sum, int remaining_sum)
{
    if (curr_sum == target)
    {
        print();
        return;
    }

    if (k >= n)
    {
        return;
    }

    // include
    x[k] = 1;
    if (curr_sum + w[k] <= target)
    {
        sum_of_subsets(k + 1, curr_sum + w[k], remaining_sum - w[k]);
    }

    // exclude
    x[k] = 0;
    if (curr_sum + remaining_sum - w[k] >= target)
    {
        sum_of_subsets(k + 1, curr_sum, remaining_sum - w[k]);
    }
}

int main()
{
    cout << "Enter number of elements: ";
    cin >> n;

    cout << "Enter elements: ";
    int total_sum = 0;
    for (int i = 0; i < n; i++)
    {
        cin >> w[i];
        total_sum += w[i];
    }

    cout << "Enter target sum: ";
    cin >> target;

    auto start = steady_clock::now();

    sum_of_subsets(0, 0, total_sum);

    auto end = steady_clock::now();

    auto duration = duration_cast<microseconds>(end - start);

    cout << "Execution Time: " << duration.count() << " microseconds" << endl;

    return 0;
}