#include <iostream>
#include <chrono>
using namespace std;
using namespace std::chrono;

int main()
{
    int n;

    cout << "Enter number of keys: ";
    cin >> n;

    double p[50]; // successful
    double q[50]; // unsuccessful

    cout << "Enter successful search probabilities:\n";
    for (int i = 1; i <= n; i++)
        cin >> p[i];

    cout << "Enter unsuccessful search probabilities:\n";
    for (int i = 0; i <= n; i++)
        cin >> q[i];

    double cost[50][50];
    double weight[50][50];
    int root[50][50];

    auto start = high_resolution_clock::now();

    // Base case
    for (int i = 1; i <= n + 1; i++)
    {
        cost[i][i - 1] = q[i - 1];
        weight[i][i - 1] = q[i - 1];
    }

    // Build OBST
    for (int length = 1; length <= n; length++)
    {
        for (int i = 1; i <= n - length + 1; i++)
        {
            int j = i + length - 1;

            cost[i][j] = 1000000;

            weight[i][j] = weight[i][j - 1] + p[j] + q[j];

            for (int r = i; r <= j; r++)
            {
                double current =
                    cost[i][r - 1] +
                    cost[r + 1][j] +
                    weight[i][j];

                if (current < cost[i][j])
                {
                    cost[i][j] = current;
                    root[i][j] = r;
                }
            }
        }
    }

    auto stop = high_resolution_clock::now();

    cout << "\nMinimum Expected Search Cost: " << cost[1][n] << endl;

    auto totalTime = duration_cast<microseconds>(stop - start);
    cout << "Execution Time: " << totalTime.count() << " microseconds\n";

    return 0;
}