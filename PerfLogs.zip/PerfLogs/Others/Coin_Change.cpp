#include <iostream>
using namespace std;

void sort_dec(int arr[], int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {

            if (arr[i] < arr[j])
            {
                swap(arr[i], arr[j]);
            }
        }
    }
}

void print(int arr[], int n)

{
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << "  ";
    }
}

int main()
{
    int coins[100];

    int n;
    cout << "\nEnter no of Coins : ";
    cin >> n;

    cout << "\nEnter value of coin : " << endl;
    for (int i = 0; i < n; i++)
    {
        cin >> coins[i];
    }

    int amount;
    cout << "\nEnter a amount : ";
    cin >> amount;

    // sorting in decreasing order
    sort_dec(coins, n);

    cout << "\nCoins Sorted in decreasing order  : ";
    print(coins, n);

    int ans[100];
    int k = 0;

    for (int i = 0; i < n; i++)
    {
        while (amount >= coins[i])
        {
            ans[k++] = coins[i];
            amount = amount - coins[i];
        }
    }

    if (amount != 0)
    {
        cout << "\nNot possible with given coins" << endl;
        return -1;
    }

    cout << "\n-----------------------------------------" << endl;
    cout << "Coins needed to form the amount : " << k << endl;
    cout << "Coins used to form the amount : " << endl;
    print(ans, k);

    return 0;
}