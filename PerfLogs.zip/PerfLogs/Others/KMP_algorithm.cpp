#include <iostream>
#include <vector>
#include <chrono>
using namespace std;

void computeLPS(string pattern, vector<int> &lps)
{
    int length = 0;
    lps[0] = 0;

    int i = 1;

    while (i < pattern.length())
    {
        if (pattern[i] == pattern[length])
        {
            length++;
            lps[i] = length;
            i++;
        }
        else
        {
            if (length != 0)
            {
                length = lps[length - 1];
            }
            else
            {
                lps[i] = 0;
                i++;
            }
        }
    }
}

void KMPSearch(string text, string pattern)
{
    int n = text.length();
    int m = pattern.length();

    vector<int> lps(m);

    auto start = chrono::high_resolution_clock::now();

    computeLPS(pattern, lps);

    cout << "\nLPS Table:\n";
    for (int i = 0; i < m; i++)
    {
        cout << lps[i] << " ";
    }
    cout << endl;

    int i = 0;
    int j = 0;
    bool found = false;

    while (i < n)
    {
        if (pattern[j] == text[i])
        {
            i++;
            j++;
        }

        if (j == m)
        {
            cout << "Pattern found at index: " << i - j << endl;
            found = true;
            j = lps[j - 1];
        }
        else if (i < n && pattern[j] != text[i])
        {
            if (j != 0)
            {
                j = lps[j - 1];
            }
            else
            {
                i++;
            }
        }
    }

    if (!found)
    {
        cout << "Pattern not found in the text." << endl;
    }

    auto end = chrono::high_resolution_clock::now();

    auto duration = chrono::duration_cast<chrono::nanoseconds>(end - start);

    cout << "Time required: " << duration.count() << " nanoseconds" << endl;
}

int main()
{
    string text, pattern;

    cout << "Enter the text: ";
    cin >> text;

    cout << "Enter the pattern: ";
    cin >> pattern;

    KMPSearch(text, pattern);

    return 0;
}