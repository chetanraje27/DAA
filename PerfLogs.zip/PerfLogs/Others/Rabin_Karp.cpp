#include <iostream>
#include <chrono>

using namespace std;
using namespace chrono;

#define d 256

// Function to calculate string length
int stringLength(char str[])
{
    int len = 0;

    while (str[len] != '\0')
    {
        len++;
    }

    return len;
}

// Rabin Karp Search Function
void rabinKarpSearch(char text[], char pattern[], int q)
{
    int n = stringLength(text);
    int m = stringLength(pattern);

    int p = 0; // Hash value for pattern
    int t = 0; // Hash value for text
    int h = 1;

    int found = 0;

    // h = pow(d, m-1) % q
    for (int i = 0; i < m - 1; i++)
    {
        h = (h * d) % q;
    }

    // Calculate initial hash values
    for (int i = 0; i < m; i++)
    {
        p = (d * p + pattern[i]) % q;
        t = (d * t + text[i]) % q;
    }

    // Slide pattern over text
    for (int i = 0; i <= n - m; i++)
    {
        // Hash match
        if (p == t)
        {
            int j;

            for (j = 0; j < m; j++)
            {
                if (text[i + j] != pattern[j])
                {
                    break;
                }
            }

            if (j == m)
            {
                cout << "Pattern found at index: " << i << endl;
                found = 1;
            }
        }

        // Calculate next window hash
        if (i < n - m)
        {
            t = (d * (t - text[i] * h) + text[i + m]) % q;

            // Handle negative value
            if (t < 0)
            {
                t = t + q;
            }
        }
    }

    if (!found)
    {
        cout << "Pattern not found in the text." << endl;
    }
}

int main()
{
    char text[1000];
    char pattern[100];

    int q = 101; // Prime number

    cout << "Enter the main text: ";
    cin.getline(text, 1000);

    cout << "Enter the pattern to search: ";
    cin.getline(pattern, 100);

    auto startTime = steady_clock::now();

    rabinKarpSearch(text, pattern, q);

    auto endTime = steady_clock::now();

    auto timeTaken = duration_cast<nanoseconds>(endTime - startTime);

    cout << "Execution Time: " << timeTaken.count() << " nanoseconds" << endl;

    return 0;
}