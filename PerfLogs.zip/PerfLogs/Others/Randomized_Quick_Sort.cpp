#include <iostream>
#include <cstdlib>
#include <ctime>
#include <chrono>
using namespace std;
using namespace chrono;

void swapValues(int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}

void displayArray(int arr[], int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int partitionArray(int arr[], int low, int high)
{
    int pivot = arr[high];
    int i = low - 1;

    cout << "\nCurrent Pivot: " << pivot << endl;

    for (int j = low; j < high; j++)
    {
        if (arr[j] < pivot)
        {
            i++;
            swapValues(arr[i], arr[j]);
        }
    }

    swapValues(arr[i + 1], arr[high]);

    cout << "Array after placing pivot " << pivot << ": ";
    for (int k = low; k <= high; k++)
    {
        cout << arr[k] << " ";
    }
    cout << endl;

    return i + 1;
}

int randomizedPartition(int arr[], int low, int high)
{
    int randomIndex = low + rand() % (high - low + 1);

    cout << "\nRandom Pivot Selected: " << arr[randomIndex] << endl;

    swapValues(arr[randomIndex], arr[high]);

    return partitionArray(arr, low, high);
}

void randomizedQuickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        int pivotPosition = randomizedPartition(arr, low, high);

        randomizedQuickSort(arr, low, pivotPosition - 1);
        randomizedQuickSort(arr, pivotPosition + 1, high);
    }
}

int main()
{
    srand(time(0));

    int size;

    cout << "Enter the number of elements: ";
    cin >> size;

    int arr[size];

    cout << "Enter the elements: ";
    for (int i = 0; i < size; i++)
    {
        cin >> arr[i];
    }

    cout << "\nOriginal Array: ";
    displayArray(arr, size);

    auto startTime = high_resolution_clock::now();

    randomizedQuickSort(arr, 0, size - 1);

    auto endTime = high_resolution_clock::now();

    auto executionTime = duration_cast<microseconds>(endTime - startTime);

    cout << "\nSorted Array: ";
    displayArray(arr, size);

    cout << "\nExecution Time: " << executionTime.count() << " microseconds" << endl;

    return 0;
}