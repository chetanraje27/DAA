
#include <iostream>
#include <chrono>

using namespace std;
using namespace chrono;

int totalComparisons = 0;

void simpleSort(int arr[], int start, int size)
{
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = start; j < start + size - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int findGroupMedian(int arr[], int start, int size)
{
    simpleSort(arr, start, size);
    return arr[start + size / 2];
}

int medianOfMedians(int arr[], int left, int right)
{
    int n = right - left + 1;

    // If 5 or fewer elements
    if (n <= 5)
    {
        simpleSort(arr, left, n);
        return arr[left + n / 2];
    }

    int medianCount = 0;
    int medians[10000]; // enough for large input

    for (int i = left; i <= right; i += 5)
    {
        int groupSize = 5;
        if (i + 4 > right)
            groupSize = right - i + 1;

        medians[medianCount++] = findGroupMedian(arr, i, groupSize);
    }

    return medianOfMedians(medians, 0, medianCount - 1);
}

int partitionArray(int arr[], int low, int high)
{
    int pivot = medianOfMedians(arr, low, high);

    int pivotIndex = low;
    for (int i = low; i <= high; i++)
    {
        if (arr[i] == pivot)
        {
            pivotIndex = i;
            break;
        }
    }

    int temp = arr[pivotIndex];
    arr[pivotIndex] = arr[high];
    arr[high] = temp;

    int boundary = low;

    for (int j = low; j < high; j++)
    {
        totalComparisons++;
        if (arr[j] < pivot)
        {
            int t = arr[boundary];
            arr[boundary] = arr[j];
            arr[j] = t;
            boundary++;
        }
    }

    temp = arr[boundary];
    arr[boundary] = arr[high];
    arr[high] = temp;

    return boundary;
}

void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        int pos = partitionArray(arr, low, high);
        quickSort(arr, low, pos - 1);
        quickSort(arr, pos + 1, high);
    }
}

int main()
{
    int n;
    cout << "Enter the size of array: ";
    cin >> n;

    int arr[100000];
    int check[100000];

    for (int i = 0; i < n; i++)
    {
        arr[i] = rand();
        check[i] = arr[i];
    }

    int sample = (n < 10) ? n : 10;
    cout << "\nFew elements before sorting (first " << sample << "):\n";
    for (int i = 0; i < sample; i++)
        cout << arr[i] << " ";
    cout << "\n";

    cout << "\nQuick Sort using Median of Medians ->\n";

    auto startTime = steady_clock::now();
    quickSort(arr, 0, n - 1);
    auto endTime = steady_clock::now();

    auto timeTaken = duration_cast<nanoseconds>(endTime - startTime);

    cout << "\nArray sorted successfully.\n";
    cout << "Total comparisons -> " << totalComparisons << endl;
    cout << "Time taken -> " << timeTaken.count() << " nanoseconds\n";

    // Verification (simple check)
    simpleSort(check, 0, n);

    cout << "\nVerification ->\n";
    cout << "First element -> " << arr[0] << endl;
    cout << "Last element  -> " << arr[n - 1] << endl;

    cout << "Actual first  -> " << check[0] << endl;
    cout << "Actual last   -> " << check[n - 1] << endl;

    cout << "\nFew elements after sorting (first " << sample << "):\n";
    for (int i = 0; i < sample; i++)
        cout << arr[i] << " ";
    cout << "\n";

    cout << "Few elements after sorting (last " << sample << "):\n";
    for (int i = n - sample; i < n; i++)
        cout << arr[i] << " ";
    cout << "\n";

    return 0;
}
