// Practical :
// Prims's Algorithm
// Name :- Jagdish Babalsure
// PRN  :- 202301040166

#include <iostream>
#include <climits>
using namespace std;

int main()
{

    int arr[100][100];
    int v;

    cout << "Enter number of vertices: ";
    cin >> v;

    // input adjacency matrix
    for (int i = 0; i < v; i++)
    {
        for (int j = 0; j < v; j++)
        {
            cin >> arr[i][j]; // 0 means no edge
        }
    }

    int visited[100] = {0}; // mark visited vertices
    int parent[100];        // store MST
    int key[100];           // min weight to connect

    // initialize
    for (int i = 0; i < v; i++)
    {
        key[i] = INT_MAX;
        parent[i] = -1;
    }

    // start from vertex 0
    key[0] = 0;

    // Prim's Algorithm
    for (int count = 0; count < v - 1; count++)
    {

        int mini = INT_MAX;
        int u = -1;

        // pick minimum key vertex not visited
        for (int i = 0; i < v; i++)
        {
            if (!visited[i] && key[i] < mini)
            {
                mini = key[i];
                u = i;
            }
        }

        visited[u] = 1;

        // update adjacent vertices
        for (int j = 0; j < v; j++)
        {
            if (arr[u][j] != 0 && !visited[j] && arr[u][j] < key[j])
            {
                key[j] = arr[u][j];
                parent[j] = u;
            }
        }
    }

    // output MST
    cout << "\nEdges in MST:\n";
    int totalCost = 0;
    for (int i = 1; i < v; i++)
    {
        cout << parent[i] << " - " << i
             << "  weight = " << arr[i][parent[i]] << endl;
        totalCost += arr[i][parent[i]];
    }

    cout << "Total cost = " << totalCost << endl;

    return 0;
}

// 0 2 0 6 0
// 2 0 3 8 5
// 0 3 0 0 7
// 6 8 0 0 9
// 0 5 7 9 0