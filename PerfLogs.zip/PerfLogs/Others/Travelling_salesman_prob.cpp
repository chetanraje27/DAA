// Practical :- Travelling Salesperson Problem using Dynamic Programming
// Name :- Jagdish Babalsure
// PRN  :- 202301040166

#include <iostream>
#include <chrono>

using namespace std;
using namespace chrono;

int n;
int cost[20][20];
int dp[1 << 15][15];

int tsp(int mask, int pos)
{
    if (mask == (1 << n) - 1)
    {
        return cost[pos][0];
    }

    if (dp[mask][pos] != -1)
    {
        return dp[mask][pos];
    }

    int ans = 999999999;

    // Try visiting all unvisited cities
    for (int city = 0; city < n; city++)
    {
        if ((mask & (1 << city)) == 0)
        {
            int newAns = cost[pos][city] + tsp(mask | (1 << city), city);

            if (newAns < ans)
            {
                ans = newAns;
            }
        }
    }

    dp[mask][pos] = ans;

    return ans;
}

int main()
{
    cout << "Enter number of cities: ";
    cin >> n;

    if (n <= 1 || n > 15)
    {
        cout << "Invalid number of cities!";
        return 0;
    }

    cout << "Enter cost matrix:\n";

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> cost[i][j];
        }
    }

    int minimumCost = 0;

    auto startTime = steady_clock::now();

    // Repeat 1000 times for measurable execution time
    for (int repeat = 0; repeat < 1000; repeat++)
    {
        // Reset DP table
        for (int i = 0; i < (1 << n); i++)
        {
            for (int j = 0; j < n; j++)
            {
                dp[i][j] = -1;
            }
        }

        minimumCost = tsp(1, 0);
    }

    auto endTime = steady_clock::now();

    auto timeTaken = duration_cast<nanoseconds>(endTime - startTime);

    cout << "\nMinimum Travelling Cost: " << minimumCost << endl;

    cout << "Execution Time: " << timeTaken.count() << " nanoseconds\n";

    return 0;
}