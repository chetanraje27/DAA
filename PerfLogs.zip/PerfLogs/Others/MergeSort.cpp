#include <iostream>
#include <chrono>
#include <cstdlib>
#include <ctime>

using namespace std;
using namespace chrono;

void mergeArrays(int arr[], int left, int mid, int right)
{
    int i = left;
    int j = mid + 1;
    int k = left;

    int temp[100000];

    while (i <= mid && j <= right)
    {
        if (arr[i] <= arr[j])
            temp[k++] = arr[i++];
        else
            temp[k++] = arr[j++];
    }

    while (i <= mid)
        temp[k++] = arr[i++];

    while (j <= right)
        temp[k++] = arr[j++];

    for (int x = left; x <= right; x++)
        arr[x] = temp[x];
}

void mergeSort(int arr[], int left, int right)
{
    if (left < right)
    {
        int mid = left + (right - left) / 2;

        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);

        mergeArrays(arr, left, mid, right);
    }
}

bool verifySorted(int arr[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        if (arr[i] > arr[i + 1])
            return false;
    }
    return true;
}

int main()
{
    int n;

    cout << "Enter the size of array: ";
    cin >> n;

    if (n <= 0 || n > 100000)
    {
        cout << "Invalid array size!";
        return 0;
    }

    int arr[100000];

    srand(time(0));

    for (int i = 0; i < n; i++)
    {
        arr[i] = rand();
    }

    int sample = (n < 10) ? n : 10;

    cout << "\nFew elements before sorting (first " << sample << "):\n";
    for (int i = 0; i < sample; i++)
        cout << arr[i] << " ";
    cout << "\n";

    cout << "Few elements before sorting (last " << sample << "):\n";
    for (int i = n - sample; i < n; i++)
        cout << arr[i] << " ";
    cout << "\n----------------------------------------------------------------------" << endl;

    cout << "\nSorting using Merge Sort...\n";

    auto startTime = steady_clock::now();

    mergeSort(arr, 0, n - 1);

    auto endTime = steady_clock::now();

    auto timeTaken = duration_cast<nanoseconds>(endTime - startTime);

    cout << "\nArray sorted successfully.\n";
    cout << "Time taken by Merge Sort: "
         << timeTaken.count() << " nanoseconds\n";

    cout << "\nVerify:\n";

    if (verifySorted(arr, n))
        cout << "Array is sorted correctly.\n";
    else
        cout << "Array is not sorted correctly.\n";

    cout << "First element: " << arr[0] << endl;
    cout << "Last element : " << arr[n - 1] << endl;

    cout << "\nFew elements after sorting (first " << sample << "):\n";
    for (int i = 0; i < sample; i++)
        cout << arr[i] << " ";
    cout << "\n";

    cout << "Few elements after sorting (last " << sample << "):\n";
    for (int i = n - sample; i < n; i++)
        cout << arr[i] << " ";
    cout << "\n";

    return 0;
}