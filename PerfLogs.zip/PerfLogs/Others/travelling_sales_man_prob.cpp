#include <iostream>
#include <climits>
#include <chrono>
using namespace std;
using namespace std::chrono;

#define MAX 20

int n;
int cost[MAX][MAX];
int visited[MAX];
int final_path[MAX];
int curr_path[MAX];

int final_cost = INT_MAX;

int calculateBound(int curr_cost, int level)
{
    int bound = curr_cost;

    for (int i = 0; i < n; i++)
    {
        if (!visited[i])
        {
            int min_edge = INT_MAX;
            for (int j = 0; j < n; j++)
            {
                if (i != j && (!visited[j] || j == 0))
                {
                    if (cost[i][j] < min_edge)
                        min_edge = cost[i][j];
                }
            }
            bound += min_edge;
        }
    }
    return bound;
}

void tsp(int curr_city, int level, int curr_cost)
{

    // If all cities visited, return to start
    if (level == n)
    {
        if (cost[curr_city][0] != 0)
        {
            int total_cost = curr_cost + cost[curr_city][0];

            if (total_cost < final_cost)
            {
                final_cost = total_cost;

                for (int i = 0; i < n; i++)
                    final_path[i] = curr_path[i];

                final_path[n] = 0;
            }
        }
        return;
    }

    for (int i = 0; i < n; i++)
    {
        if (!visited[i] && cost[curr_city][i] != 0)
        {

            int temp_cost = curr_cost + cost[curr_city][i];

            // Branch and Bound pruning
            int bound = calculateBound(temp_cost, level);

            if (bound < final_cost)
            {
                curr_path[level] = i;
                visited[i] = 1;

                tsp(i, level + 1, temp_cost);

                visited[i] = 0; // backtrack
            }
        }
    }
}

int main()
{
    cout << "Enter number of cities: ";
    cin >> n;

    cout << "Enter cost matrix:\n";
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            cin >> cost[i][j];

    auto start = high_resolution_clock::now();

    for (int i = 0; i < n; i++)
        visited[i] = 0;

    // Start from city 0
    visited[0] = 1;
    curr_path[0] = 0;

    tsp(0, 1, 0);

    auto end = high_resolution_clock::now();

    auto duration = duration_cast<microseconds>(end - start);

    cout << "\nMinimum Cost: " << final_cost << endl;

    cout << "Optimal Path: ";
    for (int i = 0; i <= n; i++)
        cout << final_path[i] << " ";

    cout << endl;

    cout << "Execution Time: " << duration.count() << " microseconds" << endl;

    return 0;
}