// Practical :- Min-Max Algorithm using Divide and Conquer
// Name :- Jagdish Babalsure
// PRN No. - 202301040166

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int dcComparisons = 0;
int simpleComparisons = 0;

void MinMax(int arr[], int i, int j, int &mini, int &maxi)
{
    // Case 1 -> one element
    if (i == j)
    {
        mini = arr[i];
        maxi = arr[i];
        return;
    }

    // Case 2 -> two elements
    if (j == i + 1)
    {
        dcComparisons++;
        if (arr[i] < arr[j])
        {
            mini = arr[i];
            maxi = arr[j];
        }
        else
        {
            mini = arr[j];
            maxi = arr[i];
        }
        return;
    }

    // Case 3 -> more than two elements
    int mid = (i + j) / 2;

    int min1, max1, min2, max2;

    MinMax(arr, i, mid, min1, max1);
    MinMax(arr, mid + 1, j, min2, max2);

    // Find minimum
    dcComparisons++;
    if (min1 < min2)
        mini = min1;
    else
        mini = min2;

    // Find maximum
    dcComparisons++;
    if (max1 > max2)
        maxi = max1;
    else
        maxi = max2;
}

void SimpleMinMax(int arr[], int n, int &mini, int &maxi)
{
    mini = arr[0];
    maxi = arr[0];

    for (int i = 1; i < n; i++)
    {
        simpleComparisons++;
        if (arr[i] < mini)
            mini = arr[i];

        simpleComparisons++;
        if (arr[i] > maxi)
            maxi = arr[i];
    }
}

int main()
{
    const int n = 1024; // power of 2
    const int repeat = 10000;

    int arr[n];
    int min1, max1, min2, max2;

    srand(time(0));

    for (int i = 0; i < n; i++)
        arr[i] = rand() % 10000;

    cout << "Array size = " << n << endl;

    cout << "First 20 elements: ";
    for (int i = 0; i < 20; i++)
        cout << arr[i] << " ";
    cout << endl;

    // -------- SIMPLE MIN-MAX timing --------
    simpleComparisons = 0;
    clock_t start1 = clock();
    for (int i = 0; i < repeat; i++)
        SimpleMinMax(arr, n, min1, max1);
    clock_t end1 = clock();

    // -------- DIVIDE & CONQUER timing --------
    dcComparisons = 0;
    clock_t start2 = clock();
    for (int i = 0; i < repeat; i++)
        MinMax(arr, 0, n - 1, min2, max2);
    clock_t end2 = clock();

    double simpleTime =
        double(end1 - start1) * 1000000 / CLOCKS_PER_SEC;

    double dcTime =
        double(end2 - start2) * 1000000 / CLOCKS_PER_SEC;

    cout << "\n--- SIMPLE MIN-MAX ---" << endl;
    cout << "Minimum = " << min1 << endl;
    cout << "Maximum = " << max1 << endl;
    cout << "Comparisons (one run) = "
         << simpleComparisons / repeat << endl;
    cout << "Theoretical = " << 2 * (n - 1) << endl;
    cout << "Average Time = "
         << simpleTime / repeat << " microseconds" << endl;

    cout << "\n--- DIVIDE & CONQUER MIN-MAX ---" << endl;
    cout << "Minimum = " << min2 << endl;
    cout << "Maximum = " << max2 << endl;
    cout << "Comparisons (one run) = "
         << dcComparisons / repeat << endl;
    cout << "Theoretical = " << (3 * n) / 2 - 2 << endl;
    cout << "Average Time = "
         << dcTime / repeat << " microseconds" << endl;

    if (min1 == min2 && max1 == max2)
        cout << "\nBoth methods give same answer." << endl;
    else
        cout << "\nAnswers are different." << endl;

    return 0;
}
