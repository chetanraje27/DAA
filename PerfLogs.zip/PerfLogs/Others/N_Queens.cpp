#include <iostream>
#include <chrono>
using namespace std;
using namespace std::chrono;

#define MAX 20

int board[MAX][MAX];
int N;
int count = 0;
bool isSafe(int row, int col)
{
    int i, j;

    // Check same column
    for (i = 0; i < row; i++)
    {
        if (board[i][col] == 1)
            return false;
    }

    // Check left diagonal
    for (i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--)
    {
        if (board[i][j] == 1)
            return false;
    }

    // Check right diagonal
    for (i = row - 1, j = col + 1; i >= 0 && j < N; i--, j++)
    {
        if (board[i][j] == 1)
            return false;
    }

    return true;
}

void printBoard()
{
    count++;
    cout << "Solution " << count << ":" << endl;
    cout << "------------------" << endl;

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (board[i][j] == 1)
                cout << "Q ";
            else
                cout << ". ";
        }
        cout << endl;
    }
    cout << "------------------" << endl;
}

void solveNQueen(int row)
{
    if (row == N)
    {
        printBoard();
        return;
    }

    for (int col = 0; col < N; col++)
    {
        if (isSafe(row, col))
        {
            board[row][col] = 1;
            solveNQueen(row + 1);
            board[row][col] = 0; // backtrack
        }
    }
}

int main()
{
    cout << "Enter value of N: ";
    cin >> N;

    // Initialize board
    for (int i = 0; i < MAX; i++)
        for (int j = 0; j < MAX; j++)
            board[i][j] = 0;

    auto start = high_resolution_clock::now();

    solveNQueen(0);

    auto end = high_resolution_clock::now();

    auto duration = duration_cast<microseconds>(end - start);

    cout << "Execution Time: " << duration.count() << " microseconds" << endl;

    return 0;
}