// Practical :- Binary and Linear Search Algorithm
// Name :- Jagdish Babalsure
// PRN No. - 202301040166

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <chrono>

using namespace std;
using namespace chrono;

int linearSearch(int arr[], int n, int key)
{
    for (int i = 0; i < n; i++)
    {
        if (arr[i] == key)
            return i;
    }
    return -1;
}

int binarySearch(int arr[], int n, int key)
{
    int low = 0, high = n - 1;
    while (low <= high)
    {
        int mid = (low + high) / 2;
        if (arr[mid] == key)
            return mid;
        else if (arr[mid] < key)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1;
}

int recursiveBinarySearch(int arr[], int low, int high, int key)
{
    if (low > high)
        return -1;

    int mid = (low + high) / 2;

    if (arr[mid] == key)
        return mid;
    else if (arr[mid] < key)
        return recursiveBinarySearch(arr, mid + 1, high, key);
    else
        return recursiveBinarySearch(arr, low, mid - 1, key);
}

int randomBinarySearch(int arr[], int low, int high, int key)
{
    if (low > high)
        return -1;

    int mid = low + rand() % (high - low + 1);

    if (arr[mid] == key)
        return mid;
    else if (arr[mid] < key)
        return randomBinarySearch(arr, mid + 1, high, key);
    else
        return randomBinarySearch(arr, low, mid - 1, key);
}

int main()
{
    const int n = 10000;
    const int repeat = 100000;
    int arr[n];

    srand(time(0));

    for (int i = 0; i < n; i++)
        arr[i] = rand() % 10000;

    cout << "------------------------------------------------------------\n";
    cout << "Total elements generated: " << n << "\n";

    cout << "\nFirst 30 elements of array:\n";
    for (int i = 0; i < 30; i++)
        cout << arr[i] << " ";
    cout << "\n";

    int randomIndex = rand() % n;
    int key = arr[randomIndex];

    cout << "\nKey to search: " << key << "\n";

    auto start = high_resolution_clock::now();
    int index1 = -1;
    for (int i = 0; i < repeat; i++)
        index1 = linearSearch(arr, n, key);
    auto end = high_resolution_clock::now();

    cout << "\nLinear Search (Before Sort): "
         << duration_cast<milliseconds>(end - start).count()
         << " ms";
    cout << "\nElement found at index: " << index1 << "\n";

    sort(arr, arr + n);

    start = high_resolution_clock::now();
    int index2 = -1;
    for (int i = 0; i < repeat; i++)
        index2 = linearSearch(arr, n, key);
    end = high_resolution_clock::now();

    cout << "\nLinear Search (After Sort): "
         << duration_cast<milliseconds>(end - start).count()
         << " ms";
    cout << "\nElement found at index: " << index2 << "\n";

    cout << "\n------------------------------------------------------------\n";

    start = high_resolution_clock::now();
    int index3 = -1;
    for (int i = 0; i < repeat; i++)
        index3 = binarySearch(arr, n, key);
    end = high_resolution_clock::now();

    cout << "\nBinary Search (Iterative): "
         << duration_cast<milliseconds>(end - start).count()
         << " ms";
    cout << "\nElement found at index: " << index3 << "\n";

    start = high_resolution_clock::now();
    int index4 = -1;
    for (int i = 0; i < repeat; i++)
        index4 = recursiveBinarySearch(arr, 0, n - 1, key);
    end = high_resolution_clock::now();

    cout << "\nBinary Search (Recursive): "
         << duration_cast<milliseconds>(end - start).count()
         << " ms";
    cout << "\nElement found at index: " << index4 << "\n";

    // -------- Random Binary Search Timing --------
    start = high_resolution_clock::now();
    int index5 = -1;
    for (int i = 0; i < repeat; i++)
        index5 = randomBinarySearch(arr, 0, n - 1, key);
    end = high_resolution_clock::now();

    cout << "\nBinary Search (Random Division): "
         << duration_cast<milliseconds>(end - start).count()
         << " ms";
    cout << "\nElement found at index: " << index5 << "\n";

    return 0;
}
