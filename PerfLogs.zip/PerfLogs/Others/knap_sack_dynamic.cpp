#include <iostream>
using namespace std;

int main()
{
    int n;
    cout << "Enter number of items: ";
    cin >> n;

    int val[100], wt[100];

    for (int i = 0; i < n; i++)
    {
        cout << "\nEnter value of item " << i + 1 << " : ";
        cin >> val[i];
        cout << "Enter weight of item " << i + 1 << " : ";
        cin >> wt[i];
    }

    int capacity;
    cout << "\nEnter capacity: ";
    cin >> capacity;

    int dp[101][101];

    // Initialize DP table
    for (int i = 0; i <= n; i++)
    {
        for (int w = 0; w <= capacity; w++)
        {
            if (i == 0 || w == 0)
                dp[i][w] = 0;
        }
    }

    // Fill DP table
    for (int i = 1; i <= n; i++)
    {
        for (int w = 1; w <= capacity; w++)
        {
            if (wt[i - 1] <= w)
            {
                dp[i][w] = max(dp[i - 1][w],
                               val[i - 1] + dp[i - 1][w - wt[i - 1]]);
            }
            else
            {
                dp[i][w] = dp[i - 1][w];
            }
        }
    }

    cout << "\nMaximum Profit = " << dp[n][capacity] << endl;

    return 0;
}