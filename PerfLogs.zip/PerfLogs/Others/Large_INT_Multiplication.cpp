#include <iostream>
#include <string>
using namespace std;

// remove leading zeros
string clean(string s)
{
    while (s.length() > 1 && s[0] == '0')
        s.erase(0, 1);
    return s;
}

// add two large numbers
string add(string a, string b)
{
    string res = "";
    int carry = 0;

    int i = a.length() - 1;
    int j = b.length() - 1;

    while (i >= 0 || j >= 0 || carry)
    {
        int sum = carry;

        if (i >= 0)
            sum += a[i--] - '0';
        if (j >= 0)
            sum += b[j--] - '0';

        res = char(sum % 10 + '0') + res;
        carry = sum / 10;
    }
    return clean(res);
}

// subtract b from a (assume a >= b)
string subtract(string a, string b)
{
    string res = "";
    int borrow = 0;

    int i = a.length() - 1;
    int j = b.length() - 1;

    while (i >= 0)
    {
        int diff = (a[i] - '0') - borrow;

        if (j >= 0)
            diff -= (b[j] - '0');

        if (diff < 0)
        {
            diff += 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }

        res = char(diff + '0') + res;
        i--;
        j--;
    }
    return clean(res);
}

// multiply by 10^n
string shift(string s, int n)
{
    while (n--)
        s += '0';
    return s;
}

string karatsuba(string x, string y)
{
    x = clean(x);
    y = clean(y);

    // base case
    if (x.length() == 1 && y.length() == 1)
    {
        int mul = (x[0] - '0') * (y[0] - '0');
        return to_string(mul);
    }

    // make lengths equal
    int n = max(x.length(), y.length());

    if (x.length() < n)
        x = string(n - x.length(), '0') + x;

    if (y.length() < n)
        y = string(n - y.length(), '0') + y;

    int m = n / 2;

    // split numbers
    string a = x.substr(0, n - m);
    string b = x.substr(n - m);
    string c = y.substr(0, n - m);
    string d = y.substr(n - m);

    // recursive calls
    string ac = karatsuba(a, c);
    string bd = karatsuba(b, d);
    string ab_cd = karatsuba(add(a, b), add(c, d));

    // middle term
    string mid = subtract(subtract(ab_cd, ac), bd);

    // final result
    string result = add(add(shift(ac, 2 * m), shift(mid, m)), bd);

    return clean(result);
}

int main()
{
    string a, b;

    cout << "Enter first large number: ";
    cin >> a;

    cout << "Enter second large number: ";
    cin >> b;

    cout << "\nKaratsuba Product = " << karatsuba(a, b) << endl;

    return 0;
}