#include <iostream>
using namespace std;

int main()
{
    int n;
    cout << "Enter number of activities: ";
    cin >> n;

    int activity[100], start[100], finish[100];

    for (int i = 0; i < n; i++)
    {
        activity[i] = i + 1;
        cout << "\nEnter start of activity " << activity[i] << " : ";
        cin >> start[i];
        cout << "Enter finish of activity " << activity[i] << " : ";
        cin >> finish[i];
    }

    // Sort based on finish time
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (finish[i] > finish[j])
            {
                swap(finish[i], finish[j]);
                swap(start[i], start[j]);
                swap(activity[i], activity[j]);
            }
        }
    }

    cout << "\nSelected Activities:\n";
    cout << "Activity\tStart\tFinish\n";

    // Select first activity
    cout << activity[0] << "\t\t" << start[0] << "\t\t" << finish[0] << endl;

    int lastFinish = finish[0];

    // Select remaining activities
    for (int i = 1; i < n; i++)
    {
        if (start[i] >= lastFinish)
        {
            cout << activity[i] << "\t\t" << start[i] << "\t\t" << finish[i] << endl;
            lastFinish = finish[i];
        }
    }

    return 0;
}