#include <iostream>
#include <chrono>

using namespace std;
using namespace chrono;

#define INF 999999

int main()
{
    int n;

    cout << "Enter number of vertices: ";
    cin >> n;

    if (n <= 0 || n > 100)
    {
        cout << "Invalid number of vertices!";
        return 0;
    }

    int graph[100][100];

    cout << "Enter adjacency matrix:\n";
    cout << "Use " << INF << " for no direct edge.\n";

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> graph[i][j];
        }
    }

    auto startTime = steady_clock::now();

    // Floyd-Warshall Algorithm
    for (int k = 0; k < n; k++)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (graph[i][k] != INF && graph[k][j] != INF)
                {
                    if (graph[i][j] > graph[i][k] + graph[k][j])
                    {
                        graph[i][j] = graph[i][k] + graph[k][j];
                    }
                }
            }
        }
    }

    auto endTime = steady_clock::now();

    auto timeTaken = duration_cast<nanoseconds>(endTime - startTime);

    cout << "\nAll Pair Shortest Path Matrix:\n";

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (graph[i][j] == INF)
            {
                cout << "INF ";
            }
            else
            {
                cout << graph[i][j] << " ";
            }
        }
        cout << endl;
    }

    cout << "\nExecution Time: " << timeTaken.count() << " nanoseconds\n";

    return 0;
}