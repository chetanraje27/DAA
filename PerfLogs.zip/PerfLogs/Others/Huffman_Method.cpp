#include <iostream>
#include <chrono>

using namespace std;
using namespace chrono;

class Node
{
public:
    char ch;
    int freq;
    Node *left;
    Node *right;

    Node(char character, int frequency)
    {
        ch = character;
        freq = frequency;
        left = NULL;
        right = NULL;
    }
};

// Find minimum frequency node index
int findMin(Node *arr[], int size)
{
    int minIndex = -1;

    for (int i = 0; i < size; i++)
    {
        if (arr[i] != NULL)
        {
            minIndex = i;
            break;
        }
    }

    for (int i = 0; i < size; i++)
    {
        if (arr[i] != NULL && arr[i]->freq < arr[minIndex]->freq)
        {
            minIndex = i;
        }
    }

    return minIndex;
}

Node *buildHuffman(char chars[], int freq[], int n)
{
    Node *arr[100];

    // Create initial nodes
    for (int i = 0; i < n; i++)
    {
        arr[i] = new Node(chars[i], freq[i]);
    }

    int size = n;

    while (size > 1)
    {
        // First minimum
        int min1 = findMin(arr, size);
        Node *leftNode = arr[min1];

        arr[min1] = arr[size - 1];
        size--;

        // Second minimum
        int min2 = findMin(arr, size);
        Node *rightNode = arr[min2];

        arr[min2] = arr[size - 1];
        size--;

        // Merge
        Node *mergedNode = new Node('#', leftNode->freq + rightNode->freq);

        mergedNode->left = leftNode;
        mergedNode->right = rightNode;

        arr[size] = mergedNode;
        size++;
    }

    return arr[0];
}

// Print Huffman Codes
void printCodes(Node *root, int code[], int top)
{
    if (root->left != NULL)
    {
        code[top] = 0;
        printCodes(root->left, code, top + 1);
    }

    if (root->right != NULL)
    {
        code[top] = 1;
        printCodes(root->right, code, top + 1);
    }

    // Leaf node
    if (root->left == NULL && root->right == NULL)
    {
        cout << root->ch << " : ";

        if (top == 0)
        {
            cout << "0";
        }
        else
        {
            for (int i = 0; i < top; i++)
            {
                cout << code[i];
            }
        }

        cout << endl;
    }
}

int main()
{
    int n;

    cout << "Enter number of characters: ";
    cin >> n;

    if (n <= 0 || n > 100)
    {
        cout << "Invalid number of characters!";
        return 0;
    }

    char chars[100];
    int freq[100];

    for (int i = 0; i < n; i++)
    {
        cout << "Enter character " << i + 1 << ": ";
        cin >> chars[i];

        cout << "Enter frequency of " << chars[i] << ": ";
        cin >> freq[i];
    }

    auto startTime = steady_clock::now();

    Node *root = buildHuffman(chars, freq, n);

    int code[100];

    cout << "\nHuffman Codes:\n";
    printCodes(root, code, 0);

    auto endTime = steady_clock::now();

    auto timeTaken = duration_cast<nanoseconds>(endTime - startTime);

    cout << "\nExecution Time: " << timeTaken.count() << " nanoseconds\n";

    return 0;
}