#include <iostream>
#include <chrono>

using namespace std;
using namespace chrono;

int main()
{

    int val[100];
    int wt[100];

    int n;
    cout << "\nEnter no of items : ";
    cin >> n;

    for (int i = 0; i < n; i++)
    {
        cout << "\nEnter val of item " << i + 1 << " : ";
        cin >> val[i];
        cout << "\nEnter weight of item " << i + 1 << " : ";
        cin >> wt[i];
    }

    int capacity;
    cout << "\n Enter Capacity : ";
    cin >> capacity;

    double ratio[100];

    for (int i = 0; i < n; i++)
    {
        ratio[i] = (double)val[i] / wt[i];
    }

    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (ratio[i] < ratio[j])
            {
                swap(ratio[i], ratio[j]);
                swap(val[i], val[j]);
                swap(wt[i], wt[j]);
            }
        }
    }

    cout << "\nAfter sort in decreasing order : " << endl;
    cout << "\nvalue\tweight\tratio" << endl;

    for (int i = 0; i < n; i++)
    {
        cout << val[i] << "\t" << wt[i] << "\t" << ratio[i] << endl;
    }

    double final_wt = 0;
    double final_val = 0;

    double item_taken[100];
    int k = 0;

    for (int i = 0; i < n; i++)
    {

        if (final_wt + wt[i] <= capacity)
        {
            final_wt += wt[i];
            final_val += val[i];
            item_taken[k++] = wt[i];
        }
        else
        {
            double r = (capacity - final_wt) / wt[i];
            final_wt += r * wt[i];
            final_val += r * val[i];
            item_taken[k++] = r * wt[i];
            break;
        }
    }

    cout << "\nFinal value : " << final_val << endl;

    cout << "\nItems taken (weights) : ";
    for (int i = 0; i < k; i++)
    {
        cout << item_taken[i] << " ";
    }

    return 0;
}
