#include <iostream>
using namespace std;

int main()
{
    int n;
    cout << "Enter number of jobs: ";
    cin >> n;

    int job[100], deadline[100], profit[100];

    // Input
    for (int i = 0; i < n; i++)
    {
        job[i] = i + 1;
        cout << "\nEnter deadline of job " << job[i] << " : ";
        cin >> deadline[i];
        cout << "Enter profit of job " << job[i] << " : ";
        cin >> profit[i];
    }

    // Sort jobs in descending order of profit
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (profit[i] < profit[j])
            {
                swap(profit[i], profit[j]);
                swap(deadline[i], deadline[j]);
                swap(job[i], job[j]);
            }
        }
    }

    // Find maximum deadline
    int maxDeadline = 0;
    for (int i = 0; i < n; i++)
    {
        if (deadline[i] > maxDeadline)
            maxDeadline = deadline[i];
    }

    int slot[100];

    // Initialize slots as empty
    for (int i = 0; i < maxDeadline; i++)
        slot[i] = -1;

    int totalProfit = 0;

    // Job sequencing
    for (int i = 0; i < n; i++)
    {
        for (int j = deadline[i] - 1; j >= 0; j--)
        {
            if (slot[j] == -1)
            {
                slot[j] = i;
                totalProfit += profit[i];
                break;
            }
        }
    }

    cout << "\nSelected Jobs:\n";
    cout << "Job\tDeadline\tProfit\n";

    for (int i = 0; i < maxDeadline; i++)
    {
        if (slot[i] != -1)
        {
            int idx = slot[i];
            cout << job[idx] << "\t" << deadline[idx] << "\t\t" << profit[idx] << endl;
        }
    }

    cout << "\nTotal Profit = " << totalProfit << endl;

    return 0;
}