#include <iostream>
using namespace std;

int main()
{
    int n;
    cout << "Enter number of trips: ";
    cin >> n;

    int trip[100];
    int start[100];
    int finish[100];

    for (int i = 0; i < n; i++)
    {
        trip[i] = i + 1;
        cout << "\nEnter start time of trip " << trip[i] << " : ";
        cin >> start[i];
        cout << "Enter finish time of trip " << trip[i] << " : ";
        cin >> finish[i];
    }

    cout << "\nTrip\tStart\tFinish\n";
    for (int i = 0; i < n; i++)
    {
        cout << trip[i] << "\t" << start[i] << "\t" << finish[i] << endl;
    }

    // sort trips based on start time
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (start[i] > start[j])
            {
                swap(start[i], start[j]);
                swap(finish[i], finish[j]);
                swap(trip[i], trip[j]);
            }
        }
    }

    cout << "\n------------Sorted based on Start Time------------\n";
    cout << "Trip\tStart\tFinish\n";
    for (int i = 0; i < n; i++)
    {
        cout << trip[i] << "\t" << start[i] << "\t" << finish[i] << endl;
    }

    // cab end times
    int cabEnd[100];
    int cabCount = 0;

    for (int i = 0; i < n; i++)
    {
        int assigned = 0;

        // check if any cab is free
        for (int j = 0; j < cabCount; j++)
        {
            if (start[i] >= cabEnd[j])
            {
                cabEnd[j] = finish[i];
                assigned = 1;
                break;
            }
        }

        // if no cab available, allocate new cab
        if (!assigned)
        {
            cabEnd[cabCount] = finish[i];
            cabCount++;
        }
    }

    cout << "\nMinimum number of cabs required = " << cabCount << endl;

    return 0;
}
