#include <iostream>
#include <chrono>

using namespace std;
using namespace chrono;

void printOptimalOrder(int bracket[100][100], int i, int j)
{
    if (i == j)
    {
        cout << "A" << i;
        return;
    }

    cout << "(";

    printOptimalOrder(bracket, i, bracket[i][j]);

    printOptimalOrder(bracket, bracket[i][j] + 1, j);

    cout << ")";
}

int main()
{
    int n;

    cout << "Enter number of matrices: ";
    cin >> n;

    if (n <= 0 || n > 100)
    {
        cout << "Invalid number of matrices!";
        return 0;
    }

    int p[101];

    cout << "Enter dimensions array (size " << n + 1 << "):\n";

    for (int i = 0; i <= n; i++)
    {
        cin >> p[i];
    }

    int m[100][100];
    int bracket[100][100];

    auto startTime = steady_clock::now();

    // Cost is zero for one matrix
    for (int i = 1; i <= n; i++)
    {
        m[i][i] = 0;
    }

    // Chain length
    for (int L = 2; L <= n; L++)
    {
        for (int i = 1; i <= n - L + 1; i++)
        {
            int j = i + L - 1;

            m[i][j] = 999999999;

            for (int k = i; k < j; k++)
            {
                int cost = m[i][k] + m[k + 1][j] + p[i - 1] * p[k] * p[j];

                if (cost < m[i][j])
                {
                    m[i][j] = cost;
                    bracket[i][j] = k;
                }
            }
        }
    }

    auto endTime = steady_clock::now();

    auto timeTaken = duration_cast<nanoseconds>(endTime - startTime);

    cout << "\nMinimum number of multiplications: " << m[1][n] << endl;

    cout << "Optimal Parenthesization: ";
    printOptimalOrder(bracket, 1, n);

    cout << "\nExecution Time: " << timeTaken.count() << " nanoseconds\n";

    return 0;
}