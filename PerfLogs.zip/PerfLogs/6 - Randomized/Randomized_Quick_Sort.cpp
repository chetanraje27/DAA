#include <iostream>
#include <cstdlib>   
#include <ctime>     
using namespace std;

// Swap function
void swap(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}

// Partition function
int partition(int A[], int low, int high) {
    int pivot = A[high];
    int i = low - 1;

    for(int j = low; j < high; j++) {
        if(A[j] <= pivot) {
            i++;
            swap(A[i], A[j]);
        }
    }

    swap(A[i+1], A[high]);
    return i + 1;
}

// Randomized Partition
int randomizedPartition(int A[], int low, int high) {
    int randomIndex = low + rand() % (high - low + 1);
    swap(A[randomIndex], A[high]);
    return partition(A, low, high);
}

// Randomized Quick Sort
void randomizedQuickSort(int A[], int low, int high) {
    if(low < high) {
        int p = randomizedPartition(A, low, high);

        randomizedQuickSort(A, low, p - 1);
        randomizedQuickSort(A, p + 1, high);
    }
}

int main() {
    int n;

    cout << "Enter number of elements: ";
    cin >> n;

    int A[50];

    cout << "Enter elements:\n";
    for(int i = 0; i < n; i++) {
        cin >> A[i];
    }

    // Seed random number generator
    srand(time(0));

    clock_t start, end;

    start = clock();

    randomizedQuickSort(A, 0, n - 1);

    end = clock();

    cout << "\nSorted array:\n";
    for(int i = 0; i < n; i++) {
        cout << A[i] << " ";
    }

    double time_taken = double(end - start) / CLOCKS_PER_SEC;
    cout << "\nTime required: " << time_taken << " seconds\n";

    return 0;
}