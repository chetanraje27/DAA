#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// Swap function
void swap(int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}

// Partition function
int partition(int A[], int low, int high)
{
    // Select last element as pivot
    int pivot = A[high];

    int i = low - 1;

    for (int j = low; j < high; j++)
    {
        // Place smaller elements on left side
        if (A[j] <= pivot)
        {
            i++;

            swap(A[i], A[j]);
        }
    }

    // Place pivot at correct position
    swap(A[i + 1], A[high]);

    return i + 1;
}

// Randomized Partition
int randomizedPartition(int A[], int low, int high)
{
    // Select random pivot index
    int randomIndex =
        low + rand() % (high - low + 1);

    // Move random pivot to end
    swap(A[randomIndex], A[high]);

    // Perform normal partition
    return partition(A, low, high);
}

// Randomized Quick Sort
void randomizedQuickSort(int A[], int low, int high)
{
    if (low < high)
    {
        // Get partition index
        int p =
            randomizedPartition(A, low, high);

        // Sort left subarray
        randomizedQuickSort(A, low, p - 1);

        // Sort right subarray
        randomizedQuickSort(A, p + 1, high);
    }
}

int main()
{
    int n;

    // Input number of elements
    cout << "Enter number of elements: ";
    cin >> n;

    int A[50];

    // Input array elements
    cout << "Enter elements:\n";

    for (int i = 0; i < n; i++)
    {
        cin >> A[i];
    }

    // Seed random number generator
    srand(time(0));

    clock_t start, end;

    // Start timer
    start = clock();

    // Function call
    randomizedQuickSort(A, 0, n - 1);

    // Stop timer
    end = clock();

    // Display sorted array
    cout << "\nSorted array:\n";

    for (int i = 0; i < n; i++)
    {
        cout << A[i] << " ";
    }

    // Calculate execution time
    double time_taken =
        double(end - start) / CLOCKS_PER_SEC;

    cout << "\nTime required: "
         << time_taken
         << " seconds\n";

    return 0;
}