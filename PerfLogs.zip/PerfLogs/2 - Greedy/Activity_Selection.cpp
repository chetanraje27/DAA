#include <iostream>

using namespace std;

int main()
{
    int n;

    // Input number of activities
    cout << "Enter number of activities: ";
    cin >> n;

    // Arrays to store start and finish times
    int s[50], f[50];

    // Input start times
    cout << "Enter start times:\n";
    for (int i = 0; i < n; i++)
    {
        cin >> s[i];
    }

    // Input finish times
    cout << "Enter finish times:\n";
    for (int i = 0; i < n; i++)
    {
        cin >> f[i];
    }

    // --------------------------------------------------
    // Sort activities according to finish time
    // Smallest finish time should come first
    //
    // While swapping finish times,
    // corresponding start times must also be swapped
    // --------------------------------------------------

    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            // Swap if current finish time is greater
            if (f[j] > f[j + 1])
            {
                // Swap finish times
                int temp = f[j];
                f[j] = f[j + 1];
                f[j + 1] = temp;

                // Swap corresponding start times
                temp = s[j];
                s[j] = s[j + 1];
                s[j + 1] = temp;
            }
        }
    }

    cout << "\nSelected Activities are:\n";

    // --------------------------------------------------
    // Greedy Approach:
    //
    // 1. Select first activity
    // 2. Select next activity whose start time
    //    is greater than or equal to previous
    //    selected activity's finish time
    // --------------------------------------------------

    // First activity is always selected
    int i = 0;

    cout << "A" << i + 1 << " ";

    // Check remaining activities
    for (int j = 1; j < n; j++)
    {
        // Select activity if it does not overlap
        if (s[j] >= f[i])
        {
            cout << "A" << j + 1 << " ";

            // Update last selected activity
            i = j;
        }
    }

    cout << endl;

    return 0;
}