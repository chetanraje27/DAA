#include <iostream>

using namespace std;

// Structure to store details of each item
struct Item
{
    int weight;
    int profit;
};

// Function to sort items according to Profit/Weight ratio
// Items with higher ratio are placed first
void sortItems(Item items[], int n)
{
    // Bubble Sort
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            // Calculate ratio of current item
            float ratio1 = (float)items[j].profit / items[j].weight;

            // Calculate ratio of next item
            float ratio2 = (float)items[j + 1].profit / items[j + 1].weight;

            // Swap if next item has greater ratio
            if (ratio1 < ratio2)
            {
                Item temp = items[j];
                items[j] = items[j + 1];
                items[j + 1] = temp;
            }
        }
    }
}

// Function to solve Fractional Knapsack problem
float fractionalKnapsack(Item items[], int n, int capacity)
{
    // Stores final maximum profit
    float totalProfit = 0.0;

    // First sort items according to Profit/Weight ratio
    sortItems(items, n);

    cout << "\nItems selected in knapsack:\n";

    // Traverse all items
    for (int i = 0; i < n; i++)
    {
        // Case 1:
        // If complete item can fit into knapsack
        if (items[i].weight <= capacity)
        {
            // Reduce remaining capacity
            capacity = capacity - items[i].weight;

            // Add full profit
            totalProfit = totalProfit + items[i].profit;

            cout << "Item " << i + 1
                 << " taken completely"
                 << " (Weight = " << items[i].weight
                 << ", Profit = " << items[i].profit << ")\n";
        }

        // Case 2:
        // Only some fraction of item can fit
        else
        {
            // Find fraction that can be taken
            float fraction = (float)capacity / items[i].weight;

            // Add fractional profit
            totalProfit = totalProfit +
                          (items[i].profit * fraction);

            cout << "Item " << i + 1
                 << " taken fractionally"
                 << " (Fraction = " << fraction << ")\n";

            // Knapsack becomes full
            break;
        }
    }

    // Return final maximum profit
    return totalProfit;
}

int main()
{
    int n, capacity;

    // Input number of items
    cout << "Enter number of items: ";
    cin >> n;

    // Array of structure items
    Item items[n];

    // Input weight and profit of each item
    for (int i = 0; i < n; i++)
    {
        cout << "\nEnter weight of item " << i + 1 << ": ";
        cin >> items[i].weight;

        cout << "Enter profit of item " << i + 1 << ": ";
        cin >> items[i].profit;
    }

    // Input knapsack capacity
    cout << "\nEnter capacity of knapsack: ";
    cin >> capacity;

    // Function call
    float maxProfit = fractionalKnapsack(items, n, capacity);

    // Display final answer
    cout << "\nMaximum Profit = " << maxProfit;

    return 0;
}