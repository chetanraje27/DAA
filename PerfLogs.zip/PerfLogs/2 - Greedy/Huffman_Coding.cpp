#include <iostream>

using namespace std;

// Structure for Huffman Node
struct Node
{
    char ch;          // Character
    int freq;         // Frequency
    Node *left;       // Left child
    Node *right;      // Right child
};

// Function to create a new node
Node* createNode(char ch, int freq)
{
    Node* newNode = new Node;

    newNode->ch = ch;
    newNode->freq = freq;

    newNode->left = NULL;
    newNode->right = NULL;

    return newNode;
}

// Function to print Huffman Codes
void printCodes(Node* root, int code[], int top)
{
    // Left edge = 0
    if (root->left)
    {
        code[top] = 0;
        printCodes(root->left, code, top + 1);
    }

    // Right edge = 1
    if (root->right)
    {
        code[top] = 1;
        printCodes(root->right, code, top + 1);
    }

    // Leaf node means character found
    if (!root->left && !root->right)
    {
        cout << root->ch << " : ";

        for (int i = 0; i < top; i++)
        {
            cout << code[i];
        }

        cout << endl;
    }
}

int main()
{
    int n;

    // Input number of characters
    cout << "Enter number of characters: ";
    cin >> n;

    char ch[50];
    int freq[50];

    // Input characters and frequencies
    for (int i = 0; i < n; i++)
    {
        cout << "\nEnter character: ";
        cin >> ch[i];

        cout << "Enter frequency of " << ch[i] << ": ";
        cin >> freq[i];
    }

    // Array of node pointers
    Node* nodes[100];

    // Create initial nodes
    for (int i = 0; i < n; i++)
    {
        nodes[i] = createNode(ch[i], freq[i]);
    }

    int size = n;

    // --------------------------------------------------
    // Huffman Algorithm
    //
    // Repeat until only one node remains:
    // 1. Find two nodes with minimum frequency
    // 2. Create new node with combined frequency
    // 3. Attach smaller nodes as children
    // --------------------------------------------------

    while (size > 1)
    {
        // Assume first two nodes are minimum
        int min1 = 0;
        int min2 = 1;

        // Arrange min1 and min2 properly
        if (nodes[min1]->freq > nodes[min2]->freq)
        {
            int temp = min1;
            min1 = min2;
            min2 = temp;
        }

        // Find two smallest frequencies
        for (int i = 2; i < size; i++)
        {
            if (nodes[i]->freq < nodes[min1]->freq)
            {
                min2 = min1;
                min1 = i;
            }
            else if (nodes[i]->freq < nodes[min2]->freq)
            {
                min2 = i;
            }
        }

        // Create new internal node
        Node* newNode = createNode('#',
                                   nodes[min1]->freq +
                                   nodes[min2]->freq);

        // Attach children
        newNode->left = nodes[min1];
        newNode->right = nodes[min2];

        // Replace min1 with new node
        nodes[min1] = newNode;

        // Remove min2 from array
        for (int i = min2; i < size - 1; i++)
        {
            nodes[i] = nodes[i + 1];
        }

        size--;
    }

    // Root of Huffman Tree
    Node* root = nodes[0];

    int code[50];

    cout << "\nHuffman Codes:\n";

    // Print generated codes
    printCodes(root, code, 0);

    return 0;
}