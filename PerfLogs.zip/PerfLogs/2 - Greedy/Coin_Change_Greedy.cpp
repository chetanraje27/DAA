#include <iostream>

using namespace std;

int main()
{
    int n;   // Number of coin denominations
    int V;   // Amount to be paid

    // Input number of denominations
    cout << "Enter number of denominations: ";
    cin >> n;

    int D[n]; // Array to store coin denominations

    // Input coin values
    cout << "Enter the denominations: ";
    for (int i = 0; i < n; i++)
    {
        cin >> D[i];
    }

    // Input amount
    cout << "Enter the amount to pay: ";
    cin >> V;

    // ---------------------------------------------------
    // Sorting denominations in descending order
    // Largest denomination should come first
    // Example:
    // Before sorting -> 1 5 2 10
    // After sorting  -> 10 5 2 1
    // ---------------------------------------------------

    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            // Swap if current denomination is smaller
            if (D[i] < D[j])
            {
                int temp = D[i];
                D[i] = D[j];
                D[j] = temp;
            }
        }
    }

    int totalCoins = 0; // Stores total number of coins used

    cout << "\nCoins Used:\n";

    // ---------------------------------------------------
    // Greedy Approach:
    // Always take the largest possible denomination
    // until amount becomes smaller than that denomination
    // ---------------------------------------------------

    for (int i = 0; i < n; i++)
    {
        // Keep taking same coin while possible
        while (V >= D[i])
        {
            cout << D[i] << " ";

            // Reduce remaining amount
            V = V - D[i];

            // Increase coin count
            totalCoins++;
        }
    }

    // Display total minimum coins used
    cout << "\n\nMinimum coins required = " << totalCoins;

    return 0;
}