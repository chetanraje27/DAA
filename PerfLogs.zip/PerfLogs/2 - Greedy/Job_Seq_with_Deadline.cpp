#include <iostream>

using namespace std;

int main()
{
    int n;

    // Input number of jobs
    cout << "Enter number of jobs: ";
    cin >> n;

    // Arrays to store:
    // id        -> Job ID
    // deadline  -> Deadline of job
    // profit    -> Profit of job
    int id[50], deadline[50], profit[50];

    // Input job details
    cout << "Enter job id, deadline and profit:\n";

    for (int i = 0; i < n; i++)
    {
        cin >> id[i] >> deadline[i] >> profit[i];
    }

    // --------------------------------------------------
    // Sort jobs according to profit in descending order
    // Highest profit job should come first
    //
    // While swapping profits,
    // corresponding deadline and id must also swap
    // --------------------------------------------------

    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            // Swap if current profit is smaller
            if (profit[j] < profit[j + 1])
            {
                // Swap profit
                int temp = profit[j];
                profit[j] = profit[j + 1];
                profit[j + 1] = temp;

                // Swap deadline
                temp = deadline[j];
                deadline[j] = deadline[j + 1];
                deadline[j + 1] = temp;

                // Swap job id
                temp = id[j];
                id[j] = id[j + 1];
                id[j + 1] = temp;
            }
        }
    }

    // --------------------------------------------------
    // Find maximum deadline
    // This decides total number of available slots
    // --------------------------------------------------

    int max_deadline = 0;

    for (int i = 0; i < n; i++)
    {
        if (deadline[i] > max_deadline)
        {
            max_deadline = deadline[i];
        }
    }

    // --------------------------------------------------
    // slot[i] stores index of job placed in that slot
    //
    // Initially all slots are empty
    // -1 means empty slot
    // --------------------------------------------------

    int slot[50];

    for (int i = 0; i <= max_deadline; i++)
    {
        slot[i] = -1;
    }

    int totalProfit = 0;

    // --------------------------------------------------
    // Greedy Approach:
    //
    // Pick jobs one by one according to highest profit
    //
    // Place each job in latest available slot
    // before its deadline
    // --------------------------------------------------

    for (int i = 0; i < n; i++)
    {
        // Check slots backward
        for (int j = deadline[i]; j > 0; j--)
        {
            // If slot is empty
            if (slot[j] == -1)
            {
                // Place job in slot
                slot[j] = i;

                // Add profit
                totalProfit += profit[i];

                break;
            }
        }
    }

    // Display selected jobs
    cout << "\nSelected Jobs:\n";

    for (int i = 1; i <= max_deadline; i++)
    {
        if (slot[i] != -1)
        {
            cout << "Job " << id[slot[i]] << " ";
        }
    }

    // Display maximum profit
    cout << "\nTotal Profit = " << totalProfit << endl;

    return 0;
}