#include <iostream>

using namespace std;

#define MAX 100

// Node structure for Huffman Tree
struct Node
{
    char ch;        // character
    int freq;       // frequency
    Node *left;     // left child
    Node *right;    // right child
};

// Create new node
Node* createNode(char ch, int freq)
{
    Node* newNode = new Node();

    newNode->ch = ch;
    newNode->freq = freq;
    newNode->left = NULL;
    newNode->right = NULL;

    return newNode;
}

// --------------------------------------------------
// Min Heap (simple array based implementation)
// --------------------------------------------------

void swapNode(Node* &a, Node* &b)
{
    Node* temp = a;
    a = b;
    b = temp;
}

// Sort heap based on frequency
void sortHeap(Node* heap[], int size)
{
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = 0; j < size - i - 1; j++)
        {
            if (heap[j]->freq > heap[j + 1]->freq)
            {
                swapNode(heap[j], heap[j + 1]);
            }
        }
    }
}

// Build Huffman codes recursively
void printCodes(Node* root, string code)
{
    if (root == NULL)
        return;

    // Leaf node (character found)
    if (root->ch != '$')
    {
        cout << root->ch << " : " << code << endl;
    }

    printCodes(root->left, code + "0");
    printCodes(root->right, code + "1");
}

int main()
{
    int n;

    cout << "Enter number of characters: ";
    cin >> n;

    Node* heap[MAX];

    cout << "Enter character and frequency:\n";

    // Input characters
    for (int i = 0; i < n; i++)
    {
        char ch;
        int freq;

        cin >> ch >> freq;

        heap[i] = createNode(ch, freq);
    }

    int size = n;
    
    // --------------------------------------------------
    // Build Huffman Tree
    // --------------------------------------------------

    while (size > 1)
    {
        // Sort by frequency
        sortHeap(heap, size);

        // Pick two minimum nodes
        Node* left = heap[0];
        Node* right = heap[1];

        // Create new internal node
        Node* newNode =
            createNode('$',
                       left->freq + right->freq);

        newNode->left = left;
        newNode->right = right;

        // Remove used nodes
        for (int i = 2; i < size; i++)
        {
            heap[i - 2] = heap[i];
        }

        // Add new node
        heap[size - 2] = newNode;

        size--;
    }

    // Root of Huffman Tree
    Node* root = heap[0];

    cout << "\nHuffman Codes:\n";

    printCodes(root, "");

    return 0;
}