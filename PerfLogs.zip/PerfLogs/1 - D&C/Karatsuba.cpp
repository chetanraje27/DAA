#include <iostream>

using namespace std;

// Function to find maximum of two numbers
int maximum(int a, int b)
{
    if (a > b)
        return a;
    else
        return b;
}

// Function to count digits
int countDigits(long long n)
{
    int count = 0;

    while (n > 0)
    {
        count++;
        n = n / 10;
    }

    return count;
}

// Function to calculate 10^n
long long power10(int n)
{
    long long result = 1;

    for (int i = 0; i < n; i++)
    {
        result = result * 10;
    }

    return result;
}

// Karatsuba Multiplication Function
long long karatsuba(long long x, long long y)
{
    // Base case
    if (x < 10 || y < 10)
    {
        return x * y;
    }

    // Find maximum number of digits
    int n = maximum(countDigits(x), countDigits(y));

    // Divide digits into halves
    int half = n / 2;

    // Calculate 10^half
    long long divisor = power10(half);

    // Split the numbers
    long long a = x / divisor;
    long long b = x % divisor;

    long long c = y / divisor;
    long long d = y % divisor;

    // Recursive calls
    long long ac = karatsuba(a, c);
    long long bd = karatsuba(b, d);
    long long adbc = karatsuba(a + b, c + d) - ac - bd;

    // Combine the results
    return (ac * power10(2 * half)) +
           (adbc * power10(half)) +
           bd;
}

int main()
{
    long long num1, num2;

    cout << "Enter first large number: ";
    cin >> num1;

    cout << "Enter second large number: ";
    cin >> num2;

    long long result = karatsuba(num1, num2);

    cout << "Multiplication Result = " << result;

    return 0;
}