#include <iostream>

using namespace std;

// --------------------------------------------------
// Swap function
// --------------------------------------------------

void swap(int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}

// --------------------------------------------------
// Sort small group using simple Bubble Sort
// --------------------------------------------------

void sortArray(int arr[], int low, int high)
{
    for (int i = low; i < high; i++)
    {
        for (int j = low; j < high - (i - low); j++)
        {
            if (arr[j] > arr[j + 1])
            {
                swap(arr[j], arr[j + 1]);
            }
        }
    }
}

// --------------------------------------------------
// Find Median of Medians
// --------------------------------------------------

int medianOfMedians(int arr[], int low, int high)
{
    int n = high - low + 1;

    // If small array, sort and return middle element
    if (n <= 5)
    {
        sortArray(arr, low, high);

        return arr[low + n / 2];
    }

    int median[20];
    int index = 0;

    // Divide array into groups of 5
    for (int i = low; i <= high; i += 5)
    {
        int groupHigh = i + 4;

        if (groupHigh > high)
        {
            groupHigh = high;
        }

        sortArray(arr, i, groupHigh);

        // Store median of each group
        median[index++] =
            arr[i + (groupHigh - i) / 2];
    }

    // Recursively find median of medians
    return medianOfMedians(median, 0, index - 1);
}

// --------------------------------------------------
// Partition function
// --------------------------------------------------

int partition(int arr[], int low, int high, int pivot)
{
    int pivotIndex;

    // Find pivot position
    for (int i = low; i <= high; i++)
    {
        if (arr[i] == pivot)
        {
            pivotIndex = i;
            break;
        }
    }

    // Move pivot to end
    swap(arr[pivotIndex], arr[high]);

    int i = low - 1;

    for (int j = low; j < high; j++)
    {
        if (arr[j] <= pivot)
        {
            i++;

            swap(arr[i], arr[j]);
        }
    }

    // Place pivot at correct position
    swap(arr[i + 1], arr[high]);

    return i + 1;
}

// --------------------------------------------------
// Quick Sort using Median of Medians
// --------------------------------------------------

void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        // Select good pivot
        int pivot =
            medianOfMedians(arr, low, high);

        // Partition array
        int p =
            partition(arr, low, high, pivot);

        // Sort left part
        quickSort(arr, low, p - 1);

        // Sort right part
        quickSort(arr, p + 1, high);
    }
}

int main()
{
    int n;

    // Input number of elements
    cout << "Enter number of elements: ";
    cin >> n;

    int arr[100];

    // Input array elements
    cout << "Enter elements:\n";

    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    // Function call
    quickSort(arr, 0, n - 1);

    // Display sorted array
    cout << "\nSorted array:\n";

    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }

    return 0;
}