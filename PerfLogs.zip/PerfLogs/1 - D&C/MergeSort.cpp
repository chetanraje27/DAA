#include <iostream>

using namespace std;

// --------------------------------------------------
// Function to merge two sorted subarrays
// --------------------------------------------------

void merge(int arr[], int low, int mid, int high)
{
    int temp[100];

    int i = low;
    int j = mid + 1;
    int k = low;

    // Compare elements from both subarrays
    while (i <= mid && j <= high)
    {
        if (arr[i] < arr[j])
        {
            temp[k] = arr[i];
            i++;
        }
        else
        {
            temp[k] = arr[j];
            j++;
        }

        k++;
    }

    // Copy remaining elements from left subarray
    while (i <= mid)
    {
        temp[k] = arr[i];

        i++;
        k++;
    }

    // Copy remaining elements from right subarray
    while (j <= high)
    {
        temp[k] = arr[j];

        j++;
        k++;
    }

    // Copy sorted elements back to original array
    for (int i = low; i <= high; i++)
    {
        arr[i] = temp[i];
    }
}

// --------------------------------------------------
// Merge Sort Function
// --------------------------------------------------

void mergeSort(int arr[], int low, int high)
{
    if (low < high)
    {
        // Find middle index
        int mid = (low + high) / 2;

        // Sort left half
        mergeSort(arr, low, mid);

        // Sort right half
        mergeSort(arr, mid + 1, high);

        // Merge both halves
        merge(arr, low, mid, high);
    }
}

int main()
{
    int n;

    // Input number of elements
    cout << "Enter number of elements: ";
    cin >> n;

    int arr[100];

    // Input array elements
    cout << "Enter elements:\n";

    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    // Function call
    mergeSort(arr, 0, n - 1);

    // Display sorted array
    cout << "\nSorted array:\n";

    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }

    return 0;
}