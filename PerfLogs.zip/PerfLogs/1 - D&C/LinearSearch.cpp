// linear Search 
#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter the number of elements : ";
    cin >> n;
    int arr[n];
    cout << "Enter integers: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int target;
    cout << "Enter the target integer to search for: ";
    cin >> target;

    int result = -1;
    for (int i = 0; i < n; i++) {
        if (arr[i] == target) {
            result = i;
            break;
        }
    }

    if (result != -1) {
        cout << "Element found at index: " << result << endl;
    } else {
        cout << "Element not found in the array." << endl;
    }
    return 0;
}