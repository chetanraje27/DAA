#include <iostream>
using namespace std;

// Structure to hold both min and max
struct Pair {
    int min;
    int max;
};

Pair getMinMax(int arr[], int low, int high) {
    Pair result, leftSide, rightSide;
    
    // Base Case 1: Only one element in the segment
    if (low == high) {
        result.min = arr[low];
        result.max = arr[low];
        return result;
    }

    // Base Case 2: Exactly two elements in the segment
    if (high == low + 1) {
        if (arr[low] < arr[high]) {
            result.min = arr[low];
            result.max = arr[high];
        } else {
            result.min = arr[high];
            result.max = arr[low];
        }
        return result;
    }

    // Recursive Step: Divide the array
    int mid = low + (high - low) / 2;
    leftSide = getMinMax(arr, low, mid);
    rightSide = getMinMax(arr, mid + 1, high);

    // Combine: Compare results from both halves
    result.min = (leftSide.min < rightSide.min) ? leftSide.min : rightSide.min;
    result.max = (leftSide.max > rightSide.max) ? leftSide.max : rightSide.max;

    return result;
}

int main() {
    int n;
    cout << "Enter number of elements: ";
    cin >> n;
    int arr[n];
    cout << "Enter elements:" << endl;
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    
    Pair result = getMinMax(arr, 0, n - 1);

    std::cout << "Minimum element: " << result.min << std::endl;
    std::cout << "Maximum element: " << result.max << std::endl;

    return 0;
}