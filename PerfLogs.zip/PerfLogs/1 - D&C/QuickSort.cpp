#include <iostream>
using namespace std;

// Global array as specified in image_1d39fc.jpg
int a[100];

// Interchange(a, i, j) function from image_1d39fc.jpg
void Interchange(int i, int j) {
    int p = a[i];
    a[i] = a[j];
    a[j] = p;
}

// Partition(a, m, p) function from image_1d39fc.jpg
int Partition(int m, int p) {
    int v = a[m];
    int i = m;
    int j = p;

    do {
        // repeat i := i + 1 until (a[i] >= v)
        do {
            i = i + 1;
        } while (a[i] < v);

        // repeat j := j - 1 until (a[j] <= v)
        do {
            j = j - 1;
        } while (a[j] > v);

        if (i < j) {
            Interchange(i, j);
        }
    } while (i < j);

    a[m] = a[j];
    a[j] = v;
    return j;
}

// QuickSort(p, q) function from image_1d39fc.jpg
void QuickSort(int p, int q) {
    if (p < q) {
        // divide P into two subproblems
        int j = Partition(p, q + 1);

        // Solve the subproblems
        QuickSort(p, j - 1);
        QuickSort(j + 1, q);
    }
}

int main() {
    int n;

    cout << "Enter the number of elements: ";
    cin >> n;

    cout << "Enter " << n << " elements:" << endl;
    for (int k = 1; k <= n; k++) {
        cin >> a[k];
    }

    // Per line 3 & 6 of Partition in image_1d39fc.jpg:
    // a[n+1] must be >= all elements (acting as infinity/sentinel)
    a[n + 1] = 2147483647; // Max integer value

    // Initial call: QuickSort(A, 1, n)
    QuickSort(1, n);

    cout << "Sorted array: " << endl;
    for (int k = 1; k <= n; k++) {
        cout << a[k] << " ";
    }
    cout << endl;

    return 0;
}