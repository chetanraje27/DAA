#include <iostream>
using namespace std;

// Global array as defined in image_1d3259.jpg
int a[100];

// Algorithm MaxMin(i, j, max, min) from image_1d3259.jpg
// Using references for max and min to mimic the "set max and min" effect
void MaxMin(int i, int j, int &max, int &min) {
    if (i == j) {
        // Small(P) case: only one element
        max = min = a[i];
    } 
    else if (i == j - 1) {
        // Another case of Small(P): two elements
        if (a[i] < a[j]) {
            max = a[j];
            min = a[i];
        } else {
            max = a[i];
            min = a[j];
        }
    } 
    else {
        // If P is not small, divide P into subproblems
        int mid = (i + j) / 2;
        
        int max1, min1;
        
        // Solve the subproblems
        MaxMin(i, mid, max, min);
        MaxMin(mid + 1, j, max1, min1);
        
        // Combine the solutions
        if (max < max1) max = max1;
        if (min > min1) min = min1;
    }
}

int main() {
    int n;
    int maxVal, minVal;

    cout << "Enter the number of elements: ";
    cin >> n;

    if (n <= 0) {
        cout << "Invalid array size." << endl;
        return 0;
    }

    cout << "Enter " << n << " elements:" << endl;
    for (int k = 1; k <= n; k++) {
        cin >> a[k];
    }

    // Initial call based on image_1d3259.jpg parameters (1 to n)
    MaxMin(1, n, maxVal, minVal);

    cout << "Maximum element: " << maxVal << endl;
    cout << "Minimum element: " << minVal << endl;

    return 0;
}