#include <iostream>

using namespace std;

int main()
{
    int n;

    // Input number of cities
    cout << "Enter number of cities: ";
    cin >> n;

    int cost[10][10];

    // Input cost matrix
    cout << "Enter cost matrix:\n";

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> cost[i][j];
        }
    }

    // --------------------------------------------------
    // dp[mask][i]
    //
    // mask -> visited cities
    // i    -> current city
    //
    // Stores minimum cost to reach city i
    // after visiting cities in mask
    // --------------------------------------------------

    int dp[1024][10];

    // Initialize all values with large number
    for (int i = 0; i < 1024; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            dp[i][j] = 999999;
        }
    }

    // Starting city = 0
    dp[1][0] = 0;

    // --------------------------------------------------
    // Held-Karp Dynamic Programming
    // --------------------------------------------------

    for (int mask = 1; mask < (1 << n); mask++)
    {
        for (int u = 0; u < n; u++)
        {
            // Check if city u is visited
            if ((mask & (1 << u)) != 0)
            {
                for (int v = 0; v < n; v++)
                {
                    // Check if city v is not visited
                    if ((mask & (1 << v)) == 0)
                    {
                        int newMask = mask | (1 << v);

                        int newCost =
                            dp[mask][u] + cost[u][v];

                        // Store minimum cost
                        if (newCost < dp[newMask][v])
                        {
                            dp[newMask][v] = newCost;
                        }
                    }
                }
            }
        }
    }

    // --------------------------------------------------
    // Find minimum tour cost
    // --------------------------------------------------

    int ans = 999999;

    int finalMask = (1 << n) - 1;

    for (int i = 1; i < n; i++)
    {
        int tourCost =
            dp[finalMask][i] + cost[i][0];

        if (tourCost < ans)
        {
            ans = tourCost;
        }
    }

    // Display final answer
    cout << "\nMinimum travelling cost = "
         << ans;

    return 0;
}