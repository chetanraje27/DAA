#include <iostream>

using namespace std;

int main()
{
    int n;

    // Input number of vertices
    cout << "Enter number of vertices: ";
    cin >> n;

    int graph[50][50];

    // Input adjacency matrix
    cout << "Enter adjacency matrix:\n";
    cout << "Use 999 for infinity (no direct edge)\n";

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> graph[i][j];
        }
    }

    // Copy graph into distance matrix
    int dist[50][50];

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            dist[i][j] = graph[i][j];
        }
    }

    // Floyd-Warshall Algorithm
    for (int k = 0; k < n; k++)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                // Check shorter path through vertex k
                if (dist[i][k] + dist[k][j] < dist[i][j])
                {
                    dist[i][j] =
                        dist[i][k] + dist[k][j];
                }
            }
        }
    }

    // Display shortest distance matrix
    cout << "\nAll-Pairs Shortest Path Matrix:\n";

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << dist[i][j] << "\t";
        }

        cout << endl;
    }

    return 0;
}