#include <iostream>

using namespace std;

int main()
{
    int n;

    // Input number of matrices
    cout << "Enter number of matrices: ";
    cin >> n;

    int p[50];

    // Input dimensions array
    // Example: 10 20 30 40
    cout << "Enter dimensions array:\n";

    for (int i = 0; i <= n; i++)
    {
        cin >> p[i];
    }

    // dp[i][j] stores minimum multiplication cost
    int dp[50][50];

    // Base case:
    // One matrix needs 0 multiplication
    for (int i = 1; i <= n; i++)
    {
        dp[i][i] = 0;
    }

    // len = chain length
    for (int len = 2; len <= n; len++)
    {
        for (int i = 1; i <= n - len + 1; i++)
        {
            int j = i + len - 1;

            // Initialize with large value
            dp[i][j] = 999999;

            // Try all possible partitions
            for (int k = i; k < j; k++)
            {
                int cost =
                    dp[i][k] +
                    dp[k + 1][j] +
                    p[i - 1] * p[k] * p[j];

                // Store minimum cost
                if (cost < dp[i][j])
                {
                    dp[i][j] = cost;
                }
            }
        }
    }

    // Display DP Table
    cout << "\nDP Table:\n";

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (i > j)
            {
                cout << "-\t";
            }
            else
            {
                cout << dp[i][j] << "\t";
            }
        }

        cout << endl;
    }

    // Final answer
    cout << "\nMinimum multiplications = "
         << dp[1][n];

    return 0;
}