#include <iostream>
#include <climits>
using namespace std;

int minCoins(int coins[], int n, int V)
{
    int dp[V + 1];

    // Base case
    dp[0] = 0;

    // Initialize other values as infinite
    for (int i = 1; i <= V; i++)
        dp[i] = INT_MAX;

    // Fill DP table
    for (int i = 1; i <= V; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (coins[j] <= i)
            {
                int subResult = dp[i - coins[j]];

                if (subResult != INT_MAX && subResult + 1 < dp[i])
                    dp[i] = subResult + 1;
            }
        }
    }

    if (dp[V] == INT_MAX)
        return -1;

    return dp[V];
}

int main()
{
    int n, V;

    cout << "Enter number of denominations: ";
    cin >> n;

    int coins[n];

    cout << "Enter the denominations: ";
    for (int i = 0; i < n; i++)
        cin >> coins[i];

    cout << "Enter the amount to pay: ";
    cin >> V;

    int result = minCoins(coins, n, V);

    if (result == -1)
        cout << "Amount cannot be formed.";
    else
        cout << "Minimum coins required = " << result;

    return 0;
}