#include <iostream>

using namespace std;

int main()
{
    int n, W;

    // Input number of items
    cout << "Enter number of items: ";
    cin >> n;

    int w[50], v[50];

    // Input weights of items
    cout << "Enter weights:\n";

    for (int i = 1; i <= n; i++)
    {
        cin >> w[i];
    }

    // Input values/profits of items
    cout << "Enter values:\n";

    for (int i = 1; i <= n; i++)
    {
        cin >> v[i];
    }

    // Input knapsack capacity
    cout << "Enter capacity of knapsack: ";
    cin >> W;

    // --------------------------------------------------
    // dp[i][j] represents:
    //
    // Maximum value that can be obtained
    // using first i items
    // with capacity j
    // --------------------------------------------------

    int dp[50][50];

    // --------------------------------------------------
    // Base Case Initialization
    //
    // If:
    // 1. No items available OR
    // 2. Capacity is 0
    //
    // Then maximum profit = 0
    // --------------------------------------------------

    for (int j = 0; j <= W; j++)
    {
        dp[0][j] = 0;
    }

    for (int i = 0; i <= n; i++)
    {
        dp[i][0] = 0;
    }

    // --------------------------------------------------
    // Dynamic Programming Computation
    // --------------------------------------------------

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= W; j++)
        {
            // --------------------------------------------------
            // Case 1:
            // Current item can fit in knapsack
            // --------------------------------------------------

            if (w[i] <= j)
            {
                // Value if current item is included
                int include =
                    v[i] + dp[i - 1][j - w[i]];

                // Value if current item is excluded
                int exclude =
                    dp[i - 1][j];

                // Store maximum value
                if (include > exclude)
                {
                    dp[i][j] = include;
                }
                else
                {
                    dp[i][j] = exclude;
                }
            }

            // --------------------------------------------------
            // Case 2:
            // Current item cannot fit
            // --------------------------------------------------

            else
            {
                dp[i][j] = dp[i - 1][j];
            }
        }
    }

    // --------------------------------------------------
    // Display DP Table
    // --------------------------------------------------

    cout << "\nDP Table:\n";

    for (int i = 0; i <= n; i++)
    {
        for (int j = 0; j <= W; j++)
        {
            cout << dp[i][j] << "\t";
        }

        cout << endl;
    }

    // --------------------------------------------------
    // Final Maximum Value
    // --------------------------------------------------

    cout << "\nMaximum value = " << dp[n][W];

    // --------------------------------------------------
    // Backtracking:
    // Find which items are selected
    // --------------------------------------------------

    cout << "\nSelected items: ";

    int i = n;
    int j = W;

    while (i > 0 && j > 0)
    {
        // If value changes,
        // item is included
        if (dp[i][j] != dp[i - 1][j])
        {
            cout << i << " ";

            // Reduce remaining capacity
            j = j - w[i];
        }

        // Move to previous item
        i--;
    }

    cout << endl;

    return 0;
}