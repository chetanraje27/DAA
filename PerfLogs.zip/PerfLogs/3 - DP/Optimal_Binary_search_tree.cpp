#include <iostream>
using namespace std;

int main() {
    int n;

    cout << "Enter number of keys: ";
    cin >> n;

    float p[20], q[20];
    float e[20][20], w[20][20];
    int root[20][20];

    cout << "Enter successful search probabilities (p):\n";
    for(int i = 1; i <= n; i++) {
        cin >> p[i];
    }

    cout << "Enter unsuccessful search probabilities (q):\n";
    for(int i = 0; i <= n; i++) {
        cin >> q[i];
    }

    // Initialization
    for(int i = 1; i <= n+1; i++) {
        e[i][i-1] = q[i-1];
        w[i][i-1] = q[i-1];
    }

    // OBST computation
    for(int len = 1; len <= n; len++) {
        for(int i = 1; i <= n-len+1; i++) {
            int j = i + len - 1;
            e[i][j] = 9999;

            w[i][j] = w[i][j-1] + p[j] + q[j];

            for(int r = i; r <= j; r++) {
                float cost = e[i][r-1] + e[r+1][j] + w[i][j];

                if(cost < e[i][j]) {
                    e[i][j] = cost;
                    root[i][j] = r;
                }
            }
        }
    }

    cout << "\nMinimum cost of OBST = " << e[1][n] << endl;

    cout << "\nRoot Matrix:\n";
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++) {
            if(i <= j)
                cout << root[i][j] << " ";
            else
                cout << "0 ";
        }
        cout << endl;
    }

    return 0;
}