#include <iostream>

using namespace std;

#define MAX 20

// Structure for items
struct Item
{
    int weight;
    int profit;
    float ratio;
};

Item items[MAX];

int n, capacity;

// Stores maximum profit
int maxProfit = 0;

// --------------------------------------------------
// Function to sort items according to
// profit/weight ratio
// --------------------------------------------------

void sortItems()
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (items[j].ratio < items[j + 1].ratio)
            {
                Item temp = items[j];
                items[j] = items[j + 1];
                items[j + 1] = temp;
            }
        }
    }
}

// --------------------------------------------------
// Function to calculate upper bound
// --------------------------------------------------

float bound(int level, int currWeight, int currProfit)
{
    // If weight exceeds capacity
    if (currWeight >= capacity)
    {
        return 0;
    }

    float profitBound = currProfit;

    int totalWeight = currWeight;

    int i = level + 1;

    // Add items completely while possible
    while (i < n &&
           totalWeight + items[i].weight <= capacity)
    {
        totalWeight += items[i].weight;

        profitBound += items[i].profit;

        i++;
    }

    // Add fractional profit of next item
    if (i < n)
    {
        profitBound +=
            (capacity - totalWeight) *
            items[i].ratio;
    }

    return profitBound;
}

// --------------------------------------------------
// Branch and Bound Function
// --------------------------------------------------

void knapsack(int level, int currWeight, int currProfit)
{
    // Update maximum profit
    if (currWeight <= capacity &&
        currProfit > maxProfit)
    {
        maxProfit = currProfit;
    }

    // Stop if all items processed
    if (level == n - 1)
    {
        return;
    }

    // Calculate upper bound
    float upperBound =
        bound(level, currWeight, currProfit);

    // Continue only if promising
    if (upperBound > maxProfit)
    {
        // Include current item
        knapsack(level + 1,
                 currWeight + items[level + 1].weight,
                 currProfit + items[level + 1].profit);

        // Exclude current item
        knapsack(level + 1,
                 currWeight,
                 currProfit);
    }
}

int main()
{
    // Input number of items
    cout << "Enter number of items: ";
    cin >> n;

    // Input weights and profits
    for (int i = 0; i < n; i++)
    {
        cout << "\nEnter weight of item "
             << i + 1 << ": ";
        cin >> items[i].weight;

        cout << "Enter profit of item "
             << i + 1 << ": ";
        cin >> items[i].profit;

        // Calculate profit/weight ratio
        items[i].ratio =
            (float)items[i].profit / items[i].weight;
    }

    // Input knapsack capacity
    cout << "\nEnter knapsack capacity: ";
    cin >> capacity;

    // Sort items by ratio
    sortItems();

    // Function call
    knapsack(-1, 0, 0);

    // Display final answer
    cout << "\nMaximum Profit = " << maxProfit;

    return 0;
}
