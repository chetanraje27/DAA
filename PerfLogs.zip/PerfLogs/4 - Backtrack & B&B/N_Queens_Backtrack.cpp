#include <iostream>

using namespace std;

#define MAX 20

int board[MAX][MAX];
int N;

// --------------------------------------------------
// Function to print chessboard
// --------------------------------------------------

void printBoard()
{
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            cout << board[i][j] << " ";
        }

        cout << endl;
    }

    cout << endl;
}

// --------------------------------------------------
// Function to check whether queen can be placed
// --------------------------------------------------

bool isSafe(int row, int col)
{
    // Check left side of current row
    for (int i = 0; i < col; i++)
    {
        if (board[row][i] == 1)
        {
            return false;
        }
    }

    // Check upper-left diagonal
    for (int i = row, j = col;
         i >= 0 && j >= 0;
         i--, j--)
    {
        if (board[i][j] == 1)
        {
            return false;
        }
    }

    // Check lower-left diagonal
    for (int i = row, j = col;
         i < N && j >= 0;
         i++, j--)
    {
        if (board[i][j] == 1)
        {
            return false;
        }
    }

    return true;
}

// --------------------------------------------------
// Backtracking function
// --------------------------------------------------

bool solveNQueen(int col)
{
    // All queens are placed
    if (col >= N)
    {
        printBoard();

        return true;
    }

    bool result = false;

    // Try placing queen in every row
    for (int i = 0; i < N; i++)
    {
        // Check if position is safe
        if (isSafe(i, col))
        {
            // Place queen
            board[i][col] = 1;

            // Recur for next column
            result = solveNQueen(col + 1) || result;

            // Backtrack:
            // Remove queen
            board[i][col] = 0;
        }
    }

    return result;
}

int main()
{
    // Input value of N
    cout << "Enter value of N: ";
    cin >> N;

    // Initialize board with 0
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            board[i][j] = 0;
        }
    }

    // Solve N-Queen Problem
    if (!solveNQueen(0))
    {
        cout << "No solution exists";
    }

    return 0;
}