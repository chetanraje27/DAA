#include <iostream>

using namespace std;

int n;

// Stores set elements
int set[50];

// Stores subset elements
int subset[50];

// Target sum
int target;

// --------------------------------------------------
// Function to print subset
// --------------------------------------------------

void printSubset(int size)
{
    cout << "{ ";

    for (int i = 0; i < size; i++)
    {
        cout << subset[i] << " ";
    }

    cout << "}" << endl;
}

// --------------------------------------------------
// Sum of Subsets using Branch and Bound
// --------------------------------------------------

void sumOfSubsets(int index,
                  int currentSum,
                  int remainingSum,
                  int subsetSize)
{
    // --------------------------------------------------
    // If target sum is found
    // --------------------------------------------------

    if (currentSum == target)
    {
        printSubset(subsetSize);

        return;
    }

    // --------------------------------------------------
    // Stop if:
    // 1. Index exceeds size
    // 2. Current sum exceeds target
    // 3. Even after adding remaining elements,
    //    target cannot be reached
    // --------------------------------------------------

    if (index >= n ||
        currentSum > target ||
        currentSum + remainingSum < target)
    {
        return;
    }

    // --------------------------------------------------
    // Include current element
    // --------------------------------------------------

    subset[subsetSize] = set[index];

    sumOfSubsets(index + 1,
                 currentSum + set[index],
                 remainingSum - set[index],
                 subsetSize + 1);

    // --------------------------------------------------
    // Exclude current element
    // --------------------------------------------------

    sumOfSubsets(index + 1,
                 currentSum,
                 remainingSum - set[index],
                 subsetSize);
}

int main()
{
    // Input number of elements
    cout << "Enter number of elements: ";
    cin >> n;

    int totalSum = 0;

    // Input set elements
    cout << "Enter set elements:\n";

    for (int i = 0; i < n; i++)
    {
        cin >> set[i];

        totalSum += set[i];
    }

    // Input target sum
    cout << "Enter target sum: ";
    cin >> target;

    cout << "\nSubsets are:\n";

    // Function call
    sumOfSubsets(0, 0, totalSum, 0);

    return 0;
}