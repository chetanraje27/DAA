#include <iostream>

using namespace std;

#define MAX 10
#define INF 99999

int n;

// Cost matrix
int cost[MAX][MAX];

// Visited cities array
bool visited[MAX];

// Stores minimum travelling cost
int minCost = INF;

// --------------------------------------------------
// Travelling Salesman Function
// --------------------------------------------------

void tsp(int currCity, int count, int currCost)
{
    // --------------------------------------------------
    // If all cities are visited
    // and path to starting city exists
    // --------------------------------------------------

    if (count == n && cost[currCity][0])
    {
        int totalCost =
            currCost + cost[currCity][0];

        // Update minimum cost
        if (totalCost < minCost)
        {
            minCost = totalCost;
        }

        return;
    }

    // --------------------------------------------------
    // Try visiting all unvisited cities
    // --------------------------------------------------

    for (int i = 0; i < n; i++)
    {
        // Check:
        // 1. City is not visited
        // 2. Path exists
        if (!visited[i] && cost[currCity][i])
        {
            int tempCost =
                currCost + cost[currCity][i];

            // --------------------------------------------------
            // Branch and Bound:
            // Continue only if current path cost
            // is smaller than minimum cost found
            // --------------------------------------------------

            if (tempCost < minCost)
            {
                // Mark city as visited
                visited[i] = true;

                // Recur for next city
                tsp(i, count + 1, tempCost);

                // Backtrack
                visited[i] = false;
            }
        }
    }
}

int main()
{
    // Input number of cities
    cout << "Enter number of cities: ";
    cin >> n;

    // Input cost matrix
    cout << "Enter cost matrix:\n";

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> cost[i][j];
        }
    }

    // Initialize visited array
    for (int i = 0; i < n; i++)
    {
        visited[i] = false;
    }

    // Start from city 0
    visited[0] = true;

    // Function call
    tsp(0, 1, 0);

    // Display minimum travelling cost
    cout << "\nMinimum travelling cost = "
         << minCost;

    return 0;
}