#include <iostream>
#include <ctime>   // for time calculation
using namespace std;

int main() {
    char text[100], pattern[50];

    cout << "Enter text: ";
    cin >> text;

    cout << "Enter pattern: ";
    cin >> pattern;

    int n = 0, m = 0;

    // find length manually
    while(text[n] != '\0') n++;
    while(pattern[m] != '\0') m++;

    clock_t start, end;

    start = clock();

    cout << "\nPattern found at index: ";

    for(int i = 0; i <= n - m; i++) {
        int j;

        for(j = 0; j < m; j++) {
            if(text[i + j] != pattern[j]) {
                break;
            }
        }

        if(j == m) {
            cout << i << " ";
        }
    }

    end = clock();

    double time_taken = double(end - start) / CLOCKS_PER_SEC;

    cout << "\nTime required: " << time_taken << " seconds\n";

    return 0;
}