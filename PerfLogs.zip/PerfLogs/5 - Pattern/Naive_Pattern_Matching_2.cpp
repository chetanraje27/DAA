#include <iostream>

using namespace std;

int main()
{
    char text[100], pattern[100];

    // Input text
    cout << "Enter text: ";
    cin >> text;

    // Input pattern
    cout << "Enter pattern: ";
    cin >> pattern;

    int textLength = 0;
    int patternLength = 0;

    // Find length of text
    while (text[textLength] != '\0')
    {
        textLength++;
    }

    // Find length of pattern
    while (pattern[patternLength] != '\0')
    {
        patternLength++;
    }

    bool found = false;

    // --------------------------------------------------
    // Naive Pattern Matching
    //
    // Compare pattern with every possible position
    // in the text
    // --------------------------------------------------

    for (int i = 0; i <= textLength - patternLength; i++)
    {
        int j;

        // Compare characters one by one
        for (j = 0; j < patternLength; j++)
        {
            if (text[i + j] != pattern[j])
            {
                break;
            }
        }

        // Pattern found
        if (j == patternLength)
        {
            cout << "Pattern found at position "
                 << i << endl;

            found = true;
        }
    }

    // If pattern not found
    if (!found)
    {
        cout << "Pattern not found";
    }

    return 0;
}