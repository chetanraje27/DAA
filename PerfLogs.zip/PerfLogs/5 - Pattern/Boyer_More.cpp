#include <iostream>

using namespace std;

int main()
{
    char text[100], pattern[100];

    // Input text
    cout << "Enter text: ";
    cin >> text;

    // Input pattern
    cout << "Enter pattern: ";
    cin >> pattern;

    int textLength = 0;
    int patternLength = 0;

    // Find text length
    while (text[textLength] != '\0')
    {
        textLength++;
    }

    // Find pattern length
    while (pattern[patternLength] != '\0')
    {
        patternLength++;
    }

    // --------------------------------------------------
    // Bad Character Table
    // Stores last occurrence of each character
    // --------------------------------------------------

    int badChar[256];

    // Initialize all values with -1
    for (int i = 0; i < 256; i++)
    {
        badChar[i] = -1;
    }

    // Store last occurrence of characters
    for (int i = 0; i < patternLength; i++)
    {
        badChar[(int)pattern[i]] = i;
    }

    // --------------------------------------------------
    // Boyer-Moore Searching
    // --------------------------------------------------

    int shift = 0;

    while (shift <= textLength - patternLength)
    {
        int j = patternLength - 1;

        // Compare pattern from right to left
        while (j >= 0 &&
               pattern[j] == text[shift + j])
        {
            j--;
        }

        // Pattern found
        if (j < 0)
        {
            cout << "\nPattern found at position "
                 << shift;

            // Shift pattern forward
            if (shift + patternLength < textLength)
            {
                shift =
                    shift + patternLength -
                    badChar[(int)text[shift + patternLength]];
            }
            else
            {
                shift = shift + 1;
            }
        }

        // Mismatch occurs
        else
        {
            int move =
                j - badChar[(int)text[shift + j]];

            // Shift by maximum of 1 and move
            if (move > 1)
            {
                shift = shift + move;
            }
            else
            {
                shift = shift + 1;
            }
        }
    }

    return 0;
}