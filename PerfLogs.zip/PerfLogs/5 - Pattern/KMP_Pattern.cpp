#include <iostream>
#include <ctime>   // for time calculation
using namespace std;

// Function to compute LPS array
void computeLPS(char pat[], int m, int lps[]) {
    int len = 0;
    lps[0] = 0;

    int i = 1;

    while(i < m) {
        if(pat[i] == pat[len]) {
            len++;
            lps[i] = len;
            i++;
        } else {
            if(len != 0) {
                len = lps[len - 1];
            } else {
                lps[i] = 0;
                i++;
            }
        }
    }
}

// KMP Search
void KMPSearch(char txt[], char pat[]) {
    int n = 0, m = 0;

    // find length manually
    while(txt[n] != '\0') n++;
    while(pat[m] != '\0') m++;

    int lps[50];

    computeLPS(pat, m, lps);

    cout << "\nLPS Array: ";
    for(int i = 0; i < m; i++) {
        cout << lps[i] << " ";
    }

    int i = 0, j = 0;

    cout << "\nPattern found at index: ";

    while(i < n) {
        if(txt[i] == pat[j]) {
            i++;
            j++;
        }

        if(j == m) {
            cout << (i - j) << " ";
            j = lps[j - 1];
        } else if(i < n && txt[i] != pat[j]) {
            if(j != 0) {
                j = lps[j - 1];
            } else {
                i++;
            }
        }
    }
}

int main() {
    char text[100], pattern[50];

    cout << "Enter text: ";
    cin >> text;

    cout << "Enter pattern: ";
    cin >> pattern;

    clock_t start, end;

    start = clock();

    KMPSearch(text, pattern);

    end = clock();

    double time_taken = double(end - start) / CLOCKS_PER_SEC;

    cout << "\nTime required: " << time_taken << " seconds\n";

    return 0;
}