#include <iostream>

using namespace std;

int main()
{
    char text[100], pattern[100];

    // Input text
    cout << "Enter text: ";
    cin >> text;

    // Input pattern
    cout << "Enter pattern: ";
    cin >> pattern;

    int textLength = 0;
    int patternLength = 0;

    // Find text length
    while (text[textLength] != '\0')
    {
        textLength++;
    }

    // Find pattern length
    while (pattern[patternLength] != '\0')
    {
        patternLength++;
    }

    // Prime number for hashing
    int prime = 101;

    int patternHash = 0;
    int textHash = 0;

    int h = 1;

    // --------------------------------------------------
    // Calculate h = pow(10, patternLength-1) % prime
    // --------------------------------------------------

    for (int i = 0; i < patternLength - 1; i++)
    {
        h = (h * 10) % prime;
    }

    // --------------------------------------------------
    // Calculate initial hash values
    // --------------------------------------------------

    for (int i = 0; i < patternLength; i++)
    {
        patternHash =
            (10 * patternHash + pattern[i]) % prime;

        textHash =
            (10 * textHash + text[i]) % prime;
    }

    // --------------------------------------------------
    // Rabin-Karp Searching
    // --------------------------------------------------

    for (int i = 0;
         i <= textLength - patternLength;
         i++)
    {
        // If hash values match
        if (patternHash == textHash)
        {
            int j;

            // Check characters one by one
            for (j = 0; j < patternLength; j++)
            {
                if (text[i + j] != pattern[j])
                {
                    break;
                }
            }

            // Pattern found
            if (j == patternLength)
            {
                cout << "\nPattern found at position "
                     << i;
            }
        }

        // --------------------------------------------------
        // Calculate next window hash
        // --------------------------------------------------

        if (i < textLength - patternLength)
        {
            textHash =
                (10 * (textHash - text[i] * h)
                 + text[i + patternLength]) % prime;

            // Convert negative hash to positive
            if (textHash < 0)
            {
                textHash = textHash + prime;
            }
        }
    }

    return 0;
}