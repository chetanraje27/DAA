#include <iostream>
#include <ctime>

using namespace std;

int main()
{
    char text[100], pattern[50];

    // Input text
    cout << "Enter text: ";
    cin >> text;

    // Input pattern
    cout << "Enter pattern: ";
    cin >> pattern;

    int n = 0, m = 0;

    // Find text length manually
    while (text[n] != '\0')
    {
        n++;
    }

    // Find pattern length manually
    while (pattern[m] != '\0')
    {
        m++;
    }

    // --------------------------------------------------
    // LPS Array
    //
    // lps[i] stores length of longest proper prefix
    // which is also suffix
    // --------------------------------------------------

    int lps[50];

    // Build LPS Array
    lps[0] = 0;

    int len = 0;
    int i = 1;

    while (i < m)
    {
        if (pattern[i] == pattern[len])
        {
            len++;

            lps[i] = len;

            i++;
        }
        else
        {
            if (len != 0)
            {
                len = lps[len - 1];
            }
            else
            {
                lps[i] = 0;

                i++;
            }
        }
    }

    clock_t start, end;

    start = clock();

    // --------------------------------------------------
    // KMP Pattern Matching
    // --------------------------------------------------

    int textIndex = 0;
    int patternIndex = 0;

    bool found = false;

    cout << "\nPattern found at index: ";

    while (textIndex < n)
    {
        // Characters match
        if (pattern[patternIndex] == text[textIndex])
        {
            textIndex++;
            patternIndex++;
        }

        // Pattern found
        if (patternIndex == m)
        {
            cout << textIndex - patternIndex << " ";

            found = true;

            patternIndex =
                lps[patternIndex - 1];
        }

        // Mismatch occurs
        else if (textIndex < n &&
                 pattern[patternIndex] != text[textIndex])
        {
            if (patternIndex != 0)
            {
                patternIndex =
                    lps[patternIndex - 1];
            }
            else
            {
                textIndex++;
            }
        }
    }

    end = clock();

    // Pattern not found
    if (!found)
    {
        cout << "Not Found";
    }

    // Time calculation
    double time_taken =
        double(end - start) / CLOCKS_PER_SEC;

    cout << "\nTime required: "
         << time_taken
         << " seconds\n";

    return 0;
}